"""RetinaSure AI: Streamlit application.

Run:  streamlit run app.py
"""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import streamlit as st

from src import config, privacy, uncertainty
from src.explainability import HEATMAP_LEGEND, legend_bar
from src.inference import ScreeningResult, run_screening
from src.model_loader import load_model
from src.privacy import UploadError
from src.report_generator import generate_csv, generate_html, generate_pdf
from src.uncertainty import UncertaintyConfig

st.set_page_config(page_title="RetinaSure AI", page_icon="👁️", layout="wide")

NAVY, TEAL = "#0B1F3A", "#0B7A85"
PAGES = ["Home", "Image Screening", "Results", "Model & Evaluation", "About & Safety"]

st.markdown(f"""
<style>
.block-container {{padding-top: 2rem; max-width: 1150px;}}
[data-testid="stSidebar"] {{background: {NAVY};}}
[data-testid="stSidebar"] * {{color: #F1F5F9 !important;}}
.side-brand {{font-size: 1.4rem; font-weight: 800;}} .side-brand span {{color: #5EEAD4 !important;}}
.hero {{background: linear-gradient(135deg, {NAVY} 0%, #12385F 100%); color: #fff; padding: 2rem 2.2rem; border-radius: 14px; margin-bottom: 1.2rem;}}
.hero h1 {{color: #fff; margin: 0 0 .4rem 0; font-size: 2.2rem;}} .hero p {{color: #D6E4F0; font-size: 1.05rem; margin: 0;}}
.card {{border: 1px solid #D9E2EC; border-radius: 12px; padding: 1rem 1.2rem; background: #fff; height: 100%;}}
.card h4 {{margin: 0 0 .3rem 0; color: {NAVY};}} .card p {{margin: 0; color: #334155; font-size: .93rem;}}
.step-n {{display:inline-block; width:1.7rem; height:1.7rem; line-height:1.7rem; text-align:center; border-radius:50%; background:{TEAL}; color:#fff; font-weight:700; margin-right:.5rem;}}
.disclaimer {{background:#FFF7E6; border:1px solid #F5C26B; border-left:6px solid #E0A100; padding:.8rem 1rem; border-radius:8px; color:#5B3A00; font-size:.93rem;}}
.outcome {{font-size:1.5rem; font-weight:800; color:{NAVY};}}
</style>""", unsafe_allow_html=True)


# ------------------------------------------------------------------ model (loaded once, reloaded if the file changes)
@st.cache_resource(show_spinner="Loading model...")
def _load(path: str, mtime: float):
    return load_model(path)


_mp = Path(config.DEFAULT_MODEL_PATH)
model = _load(str(_mp), _mp.stat().st_mtime if _mp.exists() else 0.0)


def go(page: str) -> None:
    st.session_state["page"] = page


# ------------------------------------------------------------------ sidebar
with st.sidebar:
    st.markdown("<div class='side-brand'>Retina<span>Sure</span> AI</div>", unsafe_allow_html=True)
    st.caption("Explainable diabetic-retinopathy screening prototype")
    if "page" not in st.session_state:
        st.session_state["page"] = "Home"
    st.radio("Navigate", PAGES, key="page", label_visibility="collapsed")
    st.divider()
    label = {"configured": "Model configured", "unconfigured": "Model not configured",
             "demo_only": "Demo-only checkpoint", "error": "Model error"}[model.status]
    st.markdown(f"**Status:** {label}")
    if not model.usable:
        st.caption("Demo mode: no clinical prediction available.")
    with st.expander("Advanced: abstention thresholds"):
        d = UncertaintyConfig()
        st.caption("Provisional defaults, not clinically validated. Choose them on a validation split (see the docs).")
        min_conf = st.slider("Minimum top-class score", 0.0, 1.0, d.min_confidence, 0.05)
        min_margin = st.slider("Minimum gap to 2nd class", 0.0, 0.5, d.min_margin, 0.05)
        max_ent = st.slider("Maximum normalised entropy", 0.3, 1.0, d.max_normalized_entropy, 0.05)
    st.caption("Educational prototype. Not a medical diagnosis.")
UCFG = UncertaintyConfig(min_conf, min_margin, max_ent)


# ------------------------------------------------------------------ rendering helpers
def render_quality(r: ScreeningResult) -> None:
    badge = {"pass": "Passed", "warn": "Questionable", "fail": "Unsuitable"}[r.quality.status]
    st.markdown(f"**Image quality (heuristic): {badge}.** {r.quality.summary}")
    st.dataframe(pd.DataFrame(r.quality.as_rows()), hide_index=True)
    st.caption(r.quality.note)


def render_outcome(r: ScreeningResult) -> None:
    d = r.decision
    st.markdown(f"<div class='outcome'>{d.title}</div>", unsafe_allow_html=True)
    {uncertainty.REPORTED: st.warning if d.caution else st.success, uncertainty.ABSTAIN: st.warning,
     uncertainty.UNGRADABLE: st.error, uncertainty.NO_MODEL: st.info}[d.status](d.message)
    if r.inference_error:
        st.error(r.inference_error)
    if d.has_prediction and r.prediction is not None:
        st.markdown(f"**Top-class softmax score:** {d.confidence:.0%}")
        st.bar_chart(pd.DataFrame({"Model score": r.prediction.probs}, index=config.CLASS_NAMES), color=TEAL, height=220)
        st.caption("Scores are softmax outputs of the model. They are not a calibrated clinical probability.")
    st.markdown("**Suggested next step:** " + d.next_step)


def render_explain(r: ScreeningResult) -> None:
    if r.explain is None:
        if r.decision.has_prediction:
            st.info("Explanation was not computed for this run.")
        else:
            st.info("No heat-map is shown because no category was reported.")
        return
    if not r.explain.available:
        st.info(r.explain.message)
        return
    c1, c2 = st.columns(2)
    c1.image(r.processed, caption="Image as seen by the model", use_container_width=True)
    c2.image(r.explain.overlay, caption="Grad-CAM overlay", use_container_width=True)
    st.image(legend_bar(400, 14), width=400)
    st.caption("Lower influence on the left, higher influence on the right")
    st.info(HEATMAP_LEGEND)
    if r.explain.message:
        st.caption(r.explain.message)


def render_model_info(r: ScreeningResult) -> None:
    if r.model_status == "configured":
        i = r.model_info
        st.write(f"Architecture **{i.get('arch')}** · input **{i.get('img_size')} px** · version **{i.get('version')}**")
        st.write(f"Training data recorded in the checkpoint: {i.get('dataset')}")
    else:
        st.write("No trained model was used for this result.")


def render_result(r: ScreeningResult) -> None:
    render_outcome(r)
    st.subheader("Explainability")
    render_explain(r)
    st.subheader("Image quality")
    render_quality(r)


# ------------------------------------------------------------------ pages
def page_home() -> None:
    st.markdown("<div class='hero'><h1>Retina<span style='color:#5EEAD4'>Sure</span> AI</h1>"
                "<p>Explainable AI-assisted screening of retinal photographs for signs of diabetic retinopathy, "
                "with image-quality checks, uncertainty handling and a downloadable report.</p></div>", unsafe_allow_html=True)
    st.markdown(f"<div class='disclaimer'><b>Prototype notice:</b> {config.SHORT_DISCLAIMER} "
                "A normal-looking result does not rule out diabetic retinopathy.</div>", unsafe_allow_html=True)
    st.write("")
    st.subheader("How the screening workflow operates")
    steps = [("Upload", "Add a fundus photograph (JPG/PNG). It is checked for type, size and corruption."),
             ("Quality check", "Heuristic checks for resolution, brightness, contrast, blur and visible retina."),
             ("Preprocess", "Black border cropped; image resized and normalised exactly as in training."),
             ("Model", "A trained network predicts one of 5 DR severity categories, only if trained weights are installed."),
             ("Uncertainty", "Low-confidence or unreliable cases are flagged and the system can abstain."),
             ("Explain and report", "Grad-CAM heat-map and a downloadable report with limitations.")]
    cols = st.columns(3)
    for i, (t, txt) in enumerate(steps):
        with cols[i % 3]:
            st.markdown(f"<div class='card'><h4><span class='step-n'>{i + 1}</span>{t}</h4><p>{txt}</p></div>", unsafe_allow_html=True)
            st.write("")
    if not model.usable:
        st.warning("**Model not configured: demo mode.** The interface, upload validation and quality checks work, but no "
                   "clinical prediction is produced. See the README to add trained weights.")
    st.button("Begin image analysis", type="primary", on_click=go, args=("Image Screening",))


def analyse_single(name: str, data: bytes) -> None:
    key = (privacy.anonymous_id(data), min_conf, min_margin, max_ent, model.status, model.meta.get("sha256", ""))
    if st.session_state.get("result_key") == key:
        return
    rgb = privacy.validate_upload(name, data)
    with st.spinner("Analysing..."):
        st.session_state["result"] = run_screening(rgb, model, privacy.anonymous_id(data), UCFG)
    st.session_state["result_filename"] = privacy.safe_filename(name)
    st.session_state["result_key"] = key


def page_screening() -> None:
    st.header("Image Screening")
    if not model.usable:
        st.warning(f"**Demo mode: no clinical prediction available.** {model.message}")
    exts = [e.lstrip(".") for e in config.SUPPORTED_EXTENSIONS]
    tab_single, tab_batch = st.tabs(["Single image", "Batch (optional)"])

    with tab_single:
        st.caption(f"Supported: JPG, JPEG, PNG. Maximum {config.MAX_FILE_MB:g} MB. Images are processed in memory and not saved by this app.")
        up = st.file_uploader("Upload a retinal fundus photograph", type=exts, key="single_up")
        if up is None:
            st.info("Upload an image to begin.")
        else:
            try:
                analyse_single(up.name, up.getvalue())
            except UploadError as exc:
                st.error(f"File rejected: {exc}")
            else:
                r: ScreeningResult = st.session_state["result"]
                c1, c2 = st.columns(2)
                c1.image(r.original_preview, caption=f"Uploaded image ({r.anon_id})", use_container_width=True)
                with c2:
                    st.markdown(f"**Analysis complete** · {r.timestamp}")
                    render_quality(r)
                st.divider()
                render_outcome(r)
                st.subheader("Explainability")
                render_explain(r)
                st.caption("The full result, with report downloads, is on the **Results** page.")
                st.button("Open Results", on_click=go, args=("Results",))

    with tab_batch:
        st.caption(f"Up to {config.MAX_BATCH_FILES} images. Heat-maps are skipped in batch mode. Batch output is a screening aid only.")
        files = st.file_uploader("Upload several images", type=exts, accept_multiple_files=True, key="batch_up")
        if files and len(files) > config.MAX_BATCH_FILES:
            st.error(f"Please upload at most {config.MAX_BATCH_FILES} images at once.")
        elif files and st.button("Analyse batch", type="primary"):
            rows, results = [], []
            bar = st.progress(0.0)
            for i, f in enumerate(files):
                data = f.getvalue()
                try:
                    res = run_screening(privacy.validate_upload(f.name, data), model, privacy.anonymous_id(data), UCFG, explain=False)
                    results.append(res)
                    rows.append({"Reference": res.anon_id, "Upload": "ok", "Quality": res.quality.status,
                                 "Outcome": res.decision.title})
                except UploadError as exc:
                    rows.append({"Reference": privacy.safe_filename(f.name), "Upload": "rejected", "Quality": "-", "Outcome": str(exc)})
                bar.progress((i + 1) / len(files))
            st.session_state["batch_rows"], st.session_state["batch_csv"] = rows, generate_csv(results)
        if st.session_state.get("batch_rows"):
            st.dataframe(pd.DataFrame(st.session_state["batch_rows"]), hide_index=True)
            st.download_button("Download batch summary (CSV)", st.session_state["batch_csv"], "retinasure_batch.csv", "text/csv", key="batch_dl")


def page_results() -> None:
    st.header("Results")
    r: ScreeningResult | None = st.session_state.get("result")
    if r is None:
        st.info("No analysis yet. Go to **Image Screening** and upload an image.")
        st.button("Go to Image Screening", on_click=go, args=("Image Screening",))
        return
    st.caption(f"Reference {r.anon_id} · {r.timestamp}")
    render_result(r)
    st.subheader("Model information")
    render_model_info(r)
    st.subheader("Limitations and follow-up")
    st.markdown("- Prototype, not clinically validated.\n- Scores are not calibrated clinical probabilities.\n"
                "- Quality checks are simple heuristics.\n- A normal-looking result does not rule out diabetic retinopathy.\n"
                "- Follow professional diabetic eye-screening guidance regardless of this output.")
    st.subheader("Report")
    c1, c2 = st.columns(2)
    inc_name = c1.checkbox("Include the original filename in the report", value=False,
                           help="Off by default: the report then contains only an anonymous reference.")
    inc_img = c2.checkbox("Include images in the report", value=True)
    fname = st.session_state.get("result_filename") if inc_name else None
    d1, d2, d3 = st.columns(3)
    d1.download_button("Download report (HTML)", generate_html(r, fname, inc_img), f"retinasure_{r.anon_id}.html", "text/html", key="dl_html")
    d2.download_button("Download report (PDF)", generate_pdf(r, fname, inc_img), f"retinasure_{r.anon_id}.pdf", "application/pdf", key="dl_pdf")
    d3.download_button("Download summary (CSV)", generate_csv([r]), f"retinasure_{r.anon_id}.csv", "text/csv", key="dl_csv")


def _ci(x) -> str:
    return "n/a" if x is None else f"{x:.2f}"


def page_model() -> None:
    st.header("Model & Evaluation")
    st.subheader("Model status")
    if model.status == "configured":
        st.success(model.message)
        i = model.info
        st.table(pd.DataFrame({"Property": ["Architecture", "Input size", "Preprocessing", "Version", "Training data (recorded)",
                                            "Created", "Weights SHA-256", "Notes"],
                               "Value": [i["arch"], f"{i['img_size']} px", i["preprocess"], i["version"], i["dataset"],
                                         i["created"], i["sha256"][:16] + "...", i["notes"] or "-"]}))
    elif model.status == "demo_only":
        st.warning(model.message)
    elif model.status == "error":
        st.error(model.message)
    else:
        st.warning(model.message)
        st.caption("Demo mode: no clinical prediction available.")

    st.subheader("Methodology")
    st.markdown(
        "- Transfer learning from an ImageNet-pretrained CNN (EfficientNet-B0 or ResNet), 5-class DR grading.\n"
        "- Class imbalance handled with class-weighted loss; fixed random seeds; patient-level splits when patient IDs exist.\n"
        "- Model selection uses the **validation** split only; the test split is used by `training/evaluate.py`.\n"
        "- Explainability: Grad-CAM on the last convolutional block.\n"
        "- Dataset provenance and licence: see `docs/DATASET_GUIDE.md` and `docs/MODEL_CARD.md`.")

    st.subheader("Evaluation metrics")
    ev_path = _mp.parent / "evaluation_metrics.json"
    if not ev_path.exists():
        st.info("**Not yet evaluated.** Metrics appear here only after `python training/evaluate.py` has been run on held-out data.")
    else:
        try:
            ev = json.loads(ev_path.read_text(encoding="utf-8"))
            prov = ev["provenance"]
            if prov.get("smoke_test"):
                st.warning("These numbers come from a smoke-test checkpoint. They only prove the pipeline runs and say nothing about accuracy.")
            if model.meta.get("sha256") and prov.get("checkpoint_sha256") != model.meta["sha256"]:
                st.warning("These metrics were computed for a different checkpoint than the one currently loaded.")
            st.caption(f"Evaluated on **{ev['n_samples']}** images ({prov.get('role')} split) · data: {prov.get('evaluated_dataset')} · {prov.get('evaluated_at')}")
            c = st.columns(4)
            c[0].metric("Accuracy", f"{ev['accuracy']:.3f}")
            c[1].metric("Quadratic weighted kappa", "n/a" if ev["quadratic_weighted_kappa"] is None else f"{ev['quadratic_weighted_kappa']:.3f}")
            c[2].metric("Macro F1", f"{ev['macro_f1']:.3f}")
            c[3].metric("Macro AUC (one-vs-rest)", "n/a" if ev["roc_auc_ovr_macro"] is None else f"{ev['roc_auc_ovr_macro']:.3f}")
            st.dataframe(pd.DataFrame(ev["per_class"]).T.rename_axis("Class").reset_index())
            st.markdown("**Confusion matrix** (rows = true class, columns = predicted)")
            st.dataframe(pd.DataFrame(ev["confusion_matrix"], index=config.CLASS_NAMES, columns=config.CLASS_NAMES))
            st.markdown("**Screening endpoints** (false negatives are the costly error)")
            rows = []
            for key, name in (("any_dr", "Any DR (grade >= 1)"), ("referable_dr", "Referable DR (grade >= 2)")):
                e = ev[key]
                rows.append({"Endpoint": name, "Sensitivity": _ci(e["sensitivity"]), "Sens. 95% CI": "n/a" if not e["sensitivity_ci95"] else f"{e['sensitivity_ci95'][0]:.2f}-{e['sensitivity_ci95'][1]:.2f}",
                             "Specificity": _ci(e["specificity"]), "Spec. 95% CI": "n/a" if not e["specificity_ci95"] else f"{e['specificity_ci95'][0]:.2f}-{e['specificity_ci95'][1]:.2f}",
                             "Missed (FN)": e["fn"], "False alarms (FP)": e["fp"]})
            st.dataframe(pd.DataFrame(rows), hide_index=True)
            st.caption(f"Expected calibration error (15 bins): {ev['expected_calibration_error']:.3f}. Measured on this split only; "
                       "a large value means softmax scores should not be read as probabilities.")
            st.markdown("**Coverage versus accuracy when withholding low-confidence results**")
            st.dataframe(pd.DataFrame(ev["risk_coverage"]["by_min_confidence"]), hide_index=True)
            st.caption(prov.get("caveat", ""))
        except (KeyError, ValueError, TypeError):
            st.error("The evaluation file exists but could not be read. Re-run `python training/evaluate.py`.")
    hist_path = _mp.with_suffix(".history.json")
    if hist_path.exists():
        try:
            hist = pd.DataFrame(json.loads(hist_path.read_text(encoding="utf-8")))
            st.subheader("Training history")
            st.line_chart(hist.set_index("epoch")[["train_loss", "val_loss"]])
        except (KeyError, ValueError, TypeError):
            pass

    st.subheader("Known limitations")
    st.markdown("- Performance on one public dataset does not establish clinical validity elsewhere (other cameras, populations, image quality).\n"
                "- Missed disease (false negatives) is the most costly error; see the sensitivity figures once evaluated.\n"
                "- Mild NPDR is subtle and usually the hardest class; rare classes have little data.")


def page_about() -> None:
    st.header("About & Safety")
    st.subheader("Problem statement")
    st.write(config.PROBLEM_STATEMENT)
    st.write("Diabetic retinopathy can damage vision without early symptoms, and regular eye screening is not available "
             "everywhere. This project explores how explainable AI could support screening workflows.")
    st.subheader("Objectives")
    st.markdown("- Build a transparent screening-aid prototype.\n- Reject or flag unreliable images.\n- Show *where* the model looked (Grad-CAM).\n"
                "- Abstain when uncertain.\n- Never fabricate predictions or metrics.")
    st.subheader("Intended use")
    st.write("Education, demonstration and research. **Not** for diagnosing, treating or triaging real patients.")
    st.markdown("<div class='disclaimer'>" + "<br>".join(config.DISCLAIMER_POINTS) + "</div>", unsafe_allow_html=True)
    st.subheader("Privacy")
    st.markdown("- Uploaded images are validated and analysed **in memory**; this app's code does not write them to disk or log their contents.\n"
                "- Only pixels are kept: EXIF and other metadata are dropped.\n"
                "- Reports use an anonymous reference, not your filename (unless you tick the option), and collect no name, date of birth or patient ID.\n"
                "- Uploaded images stay in the Streamlit server's memory during your session. If this app is deployed on a hosting service, "
                "that service's infrastructure and policies also apply. **Do not upload real patient images to a public deployment.**\n"
                "- No external service receives your image.")
    st.subheader("Project information (edit in src/config.py)")
    st.dataframe(pd.DataFrame({"Field": list(config.PROJECT_CONTACT), "Value": list(config.PROJECT_CONTACT.values())}), hide_index=True)


{"Home": page_home, "Image Screening": page_screening, "Results": page_results,
 "Model & Evaluation": page_model, "About & Safety": page_about}[st.session_state["page"]]()
