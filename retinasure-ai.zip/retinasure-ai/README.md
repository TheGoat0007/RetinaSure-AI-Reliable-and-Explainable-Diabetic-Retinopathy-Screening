# RetinaSure AI

**AI-assisted diabetic retinopathy (DR) screening prototype with explainability and safe abstention**
Problem statement **PS-068: AI-Powered Diabetic Retinopathy Detection and Explainable Screening System**

> **Educational and research prototype. Not a medical device. Output is not a medical diagnosis.**
> A normal-looking result does not rule out diabetic retinopathy. People with diabetes should follow the eye-screening schedule their doctor advises.

---

## 1. What this project is (and honestly is not)

RetinaSure AI takes a retinal fundus photograph and:

1. validates the file, 2. checks image quality, 3. preprocesses it, 4. runs a trained CNN (if you have trained one),
5. decides whether the result is trustworthy enough to show, 6. draws a Grad-CAM heatmap from the real model,
7. produces a PDF/HTML/CSV report that states its own limitations.

**Important - read this first.** This repository contains the *complete software*: app, training, evaluation, tests and docs.
It does **not** contain trained weights or a dataset, because (a) datasets have licences that forbid redistribution
and (b) no dataset could be downloaded in the environment where the code was written. Until **you** train a model
(Section 7) the app runs in **"Model not configured"** mode: upload, validation and image-quality checks work, but it
shows **no diagnosis, no confidence and no heatmap**. It never fabricates them.

See `docs/KNOWN_LIMITATIONS.md` for exactly what was and was not verified.

## 2. Features

| Feature | Where |
|---|---|
| Safe upload validation (type, size, magic bytes, decompression-bomb guard, full decode, metadata stripped) | `src/privacy.py` |
| Heuristic image-quality checks (resolution, field of view, brightness, contrast, sharpness, colour) | `src/image_quality.py` |
| Shared preprocessing for training and inference | `src/preprocessing.py` |
| Safe checkpoint loading (`weights_only`), 4 explicit model states | `src/model_loader.py` |
| 5-class DR grading (No DR, Mild, Moderate, Severe, Proliferative) | `src/inference.py` |
| Abstention on low confidence / bad images / no model | `src/uncertainty.py` |
| Grad-CAM from the loaded model | `src/explainability.py` |
| PDF, HTML and CSV reports; optional batch mode | `src/report_generator.py`, `app.py` |
| Training, evaluation (QWK, sensitivity/specificity, confusion matrix, ECE, risk-coverage) | `training/` |
| Automated tests (116) | `tests/` |

## 3. Architecture

```
upload -> validate -> quality check -> preprocess -> model -> uncertainty logic -> Grad-CAM -> report
                          |  fail                      |  no model / low confidence
                          +---------> "ungradable" ----+---------> no category shown, advise professional exam
```

A Mermaid version is in `docs/TECHNICAL_ARCHITECTURE.md`.

## 4. Project structure

```
retinasure-ai/
  app.py                  Streamlit application (5 pages)
  requirements.txt        runtime dependencies          requirements-dev.txt  + pytest
  requirements-tested.txt exact versions used in testing (reference)
  src/                    config, privacy, image_quality, preprocessing, model_loader,
                          inference, uncertainty, explainability, report_generator
  training/               dataset.py, train.py, evaluate.py
  tests/                  pytest suites (synthetic data only)
  docs/                   model card, dataset guide, safety, deployment, presentation docs
  models/                 put retinasure_dr.pt here (not included)
  scripts/                Windows PowerShell helpers
  .streamlit/config.toml  theme and upload limit
  .github/workflows/      CI that runs the tests
```

## 5. Install and run (Windows, PowerShell)

1. Install **Python 3.11 or 3.12** from python.org (tick "Add python.exe to PATH"). Python 3.13 is what the tests were run on here; 3.11/3.12 are the safest choices for PyTorch on Windows.
2. Open PowerShell in the project folder and run:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1          # if blocked: Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
python -m pip install --upgrade pip
pip install -r requirements-dev.txt   # installs the app + pytest (PyTorch is a large download)
python -m pytest                      # all tests should pass
python -m streamlit run app.py        # opens http://localhost:8501
```

Shortcut: `powershell -ExecutionPolicy Bypass -File .\scripts\setup_windows.ps1`, then `.\scripts\run_app.ps1`.
(The `.ps1` scripts were written for Windows but could not be run on Windows in the build environment.)

macOS/Linux: same, but activate with `source .venv/bin/activate`.

## 6. Get a dataset (you must do this yourself)

Datasets are not included and must not be redistributed. Read `docs/DATASET_GUIDE.md` for sources, access steps and
licence cautions. The usual starting point is **APTOS 2019 Blindness Detection** (Kaggle account + accepting the
competition rules). Arrange it like this:

```
data/aptos/
  train.csv                  (columns: id_code, diagnosis)
  train_images/<id_code>.png
```

## 7. Train, evaluate, configure

CPU training works but is slow; free GPUs are easier - see `docs/TRAINING_GUIDE.md` (Kaggle / Colab).

```powershell
# Train (splits are written to data/splits; the test split is never used for training)
python training/train.py --csv data/aptos/train.csv --image-dir data/aptos/train_images `
    --dataset-name "APTOS 2019 (Kaggle)" --epochs 15 --pretrained

# Evaluate on the held-out test split (writes models/evaluation_metrics.json)
python training/evaluate.py --checkpoint models/retinasure_dr.pt --csv data/splits/test.csv

# Optional but strongly recommended: external validation on a different dataset (see DATASET_GUIDE.md)
python training/dataset.py --csv <labels.csv> --image-dir <images> --id-col "<id col>" --label-col "<grade col>" --output data/external/other.csv
python training/evaluate.py --checkpoint models/retinasure_dr.pt --csv data/external/other.csv
```

* `--pretrained` downloads ImageNet starting weights from the internet. If that fails the script says so and trains from scratch (weaker).
* The training script saves to `models/retinasure_dr.pt` by default. **That file is what "configures" the app** - restart the app after adding it.
* To keep weights elsewhere: `$env:RETINASURE_MODEL_PATH = "D:\models\mine.pt"`.
* Choose abstention thresholds on the **validation** split (`evaluate.py --role val`), then edit `UncertaintyConfig` in `src/uncertainty.py`. See `docs/SAFETY_AND_LIMITATIONS.md`.

## 8. Tests

```powershell
python -m pytest              # 116 tests; uses synthetic images only, no dataset needed
```

Tests that use random-weight models check *plumbing only*; they say nothing about diagnostic accuracy.

## 9. Deploy

See `docs/DEPLOYMENT.md` (Streamlit Community Cloud and alternatives). You will need to sign in to your own GitHub and
Streamlit accounts yourself; nobody else (including an AI assistant) should ever ask for your password, codes or tokens.

Upload to GitHub (Git installed):

```powershell
git init
git add .
git commit -m "RetinaSure AI"
git branch -M main
# create an EMPTY repository on github.com first, then:
git remote add origin https://github.com/<your-username>/retinasure-ai.git
git push -u origin main
```

## 10. Common errors

| Symptom | Fix |
|---|---|
| `python` not recognised | Reinstall Python and tick "Add to PATH", or use `py -3.12` |
| PowerShell blocks `Activate.ps1` | `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` |
| `No module named src` when running a script | Run commands from the project root folder |
| App says "Model not configured" | No checkpoint at `models/retinasure_dr.pt` yet - train one (Section 7) |
| App says "Demo mode" | The checkpoint was made with `--smoke-test`; retrain without it |
| "Weights only load failed" | The file is not a RetinaSure checkpoint (this is a safety feature) |
| Training is very slow | Use a GPU (Kaggle/Colab), or lower `--img-size` / `--epochs` for a trial |
| `Could not load ImageNet weights` | No internet or blocked; remove `--pretrained` or fix the connection |
| Evaluation aborts with `LEAKAGE` | The CSV shares images/patients with train/val; use `data/splits/test.csv` |
| Image rejected as "not suitable" | The heuristic quality checks failed; see the table shown - retake or re-export |

## 11. Privacy and safety

* Uploads are processed in memory; nothing is written to disk by the app (tested). No names or patient IDs are requested.
* Reports carry an anonymous code derived from the image bytes; the filename is included only if you tick a box.
* **Hosted deployments transmit the image to the host's server**; the host's logs and policies then apply. Do not upload real patient images to a public demo.
* Full details: `docs/SAFETY_AND_LIMITATIONS.md`, `docs/MODEL_CARD.md`.

## 12. Licence

Code: MIT (`LICENSE`). Datasets and any trained weights keep the terms of their sources.
