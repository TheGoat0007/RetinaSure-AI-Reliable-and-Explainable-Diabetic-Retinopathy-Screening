# Deployment

**Not deployed.** This project was built in a sandbox without access to GitHub or hosting accounts. Everything below
is a documented procedure that has **not been executed** by the author. You must sign in to your own accounts;
no one should ever ask you for a password, authentication code or access token - never paste those into the app, a chat or a file.

## Before you deploy: decide about model weights

| Option | How | Notes |
|---|---|---|
| **No weights (demo)** | Deploy as is | App runs in "Model not configured" mode: upload + quality checks only. Safe for showing the interface. |
| **Commit weights to a PRIVATE repo** | `git add -f models/retinasure_dr.pt` | EfficientNet-B0 checkpoint is ~16 MB (measured), well under GitHub's file limit. **First check that the licence of your training data allows sharing a model trained on it.** Keep the repo private. |
| **Hosting that supports secrets/storage** | Fetch weights at start-up from storage you control | Requires code you would add; not implemented. |

Also decide whether a public demo should accept uploads at all. **Do not upload real patient images to a public
demo.** A hosted app sends the image to the host's server.

## Option A: Streamlit Community Cloud (free)

1. Push the project to GitHub (see README, section 9). `requirements.txt` is at the repo root.
2. Go to <https://share.streamlit.io>, sign in with GitHub and authorise access to your repository when prompted.
3. Choose **Create app** -> select the repository, branch `main`, main file `app.py`.
4. Under *Advanced settings* choose Python **3.11** or **3.12** (the tests ran on 3.13 locally and 3.11/3.12 are untested here, though CI is configured for them).
5. Deploy. The first build downloads PyTorch and can take several minutes.

**Known risks (not tested):**

* Streamlit's blog describes a roughly **1 GB resource limit** for free apps (this may have changed - check current docs). In the build environment a Python process that merely imported PyTorch and built the models peaked near **0.8 GB** (with the larger CUDA-enabled wheel, which is not what the CPU index installs). Real memory on Streamlit Cloud with the CPU wheel was **not measured**. If the app is killed for memory, use Option B.
* `requirements.txt` contains `--extra-index-url https://download.pytorch.org/whl/cpu` to get small CPU wheels on Linux. If the platform rejects this line, remove it, or pin a specific CPU wheel.

## Option B: Hugging Face Spaces (Streamlit SDK) - alternative

Create a Space with the Streamlit SDK and push the same repository files. Free CPU Spaces generally offer more memory
than Streamlit Cloud, but this was not verified here. The same data-privacy caution applies.

## Option C: run locally for the judges (most private)

`python -m streamlit run app.py` on your own laptop. No data leaves the machine. Recommended for any demo involving
images you are not fully entitled to share.

## Configuration

* `RETINASURE_MODEL_PATH` - alternative checkpoint location.
* `.streamlit/config.toml` - theme, 10 MB upload limit, usage statistics off, XSRF protection on.
* No API keys or secrets are needed; do not add any to the repository.

## After deploying - checklist

- [ ] App opens; Home shows the correct model status.
- [ ] Upload a **non-sensitive** test image (e.g. a synthetic or properly licensed one). If a model is configured, check a result, the heatmap and all three downloads.
- [ ] Upload a corrupted file and a `.txt` renamed to `.png`; both must be rejected politely.
- [ ] Edit the placeholders in `src/config.py` (`CONTACT`) and the licence holder name in `LICENSE`.
- [ ] Re-read the privacy text on the About page and make sure it still matches how you hosted it.
