# Known limitations (read before presenting)

## What was and was not verified when this was built

**Verified by running code (Linux sandbox, Python 3.13, CPU only):**
automated tests (116 passed) covering validation, quality checks, preprocessing, model-loading failure modes,
inference plumbing, Grad-CAM, uncertainty, reports, metrics, training/evaluation on tiny synthetic data, and headless
rendering of every app page; the Streamlit server started and returned "ok" on its health endpoint.
Two real bugs were found by these tests and fixed (checkpoint metadata that safe-loading rejected; a Grad-CAM
emptiness check that wrongly rejected valid maps).

**Not verified:**

* **No real model was trained** and **no real retinal image was ever processed.** All test images are synthetic drawings; test models have random weights. Therefore **nothing is known about diagnostic accuracy.** The app contains no performance numbers because none exist.
* The image-quality thresholds have never seen a real fundus photograph.
* Visual design was not inspected in a browser (no browser was available); layout, colour contrast in practice, and mobile responsiveness are unchecked.
* The single-image upload and the file-rejection message were exercised once in a real browser (Playwright) in demo mode with a synthetic image; the batch tab and the on-screen Grad-CAM view with a real model were not exercised interactively (their underlying functions are unit-tested).
* Windows scripts, GitHub Actions, Streamlit Community Cloud, Python 3.11/3.12, and GPU training were not tested.
* Memory use on a free hosting tier was not measured.

## Scientific and clinical limitations

* A single dataset result never establishes clinical validity (different cameras, populations, graders, prevalence).
* APTOS has no patient IDs, so splits there are image-level and may leak near-duplicates; results can be optimistic.
* Class imbalance: severe and proliferative cases are rare; sensitivity for them may be poor even when accuracy looks high.
* Softmax confidence is uncalibrated; abstention thresholds are placeholders until tuned on validation data.
* Grad-CAM is a coarse attention map, not a lesion detector.
* The quality module cannot detect all ungradable images and has no out-of-distribution detection; a non-retinal image that looks reddish could reach the model.
* The model grades from one photograph; it cannot see macular oedema, glaucoma, or other disease.
* Not a medical device; no regulatory review; no clinical study.

## Practical limitations

* Needs your own dataset and training run; CPU training is slow.
* Hosted use sends images to the host; the privacy text assumes you read `SAFETY_AND_LIMITATIONS.md`.
* No authentication, rate limiting or audit logging.

## How to talk about this honestly

Good: "This is a working end-to-end prototype whose safety logic and explainability are tested; here are our
measured results on dataset X and on external dataset Y, and here are their limits."
Avoid: any statement of accuracy you did not measure, "diagnoses DR", "clinically validated", or invented user numbers,
partners, awards or pilots (this project has none).
