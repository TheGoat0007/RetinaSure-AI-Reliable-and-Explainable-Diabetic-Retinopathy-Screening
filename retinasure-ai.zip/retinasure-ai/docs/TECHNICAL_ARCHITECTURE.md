# Technical architecture

## System diagram

```mermaid
flowchart TD
    U[User uploads PNG/JPEG] --> V{Validate file<br/>type, size, magic bytes,<br/>pixel limit, decode}
    V -- rejected --> E1[Polite error message<br/>nothing stored]
    V -- ok, in memory only --> Q[Image-quality heuristics<br/>resolution, field of view,<br/>brightness, contrast, sharpness, colour]
    Q --> P[Preprocess<br/>crop border, pad, resize,<br/>same code as training]
    M[(Checkpoint<br/>models/retinasure_dr.pt)] --> L[Safe loader<br/>weights_only, 4 states]
    L --> S{Model usable<br/>AND quality not failed?}
    P --> S
    Q --> S
    S -- no --> D1[Decision: model unavailable<br/>or ungradable image<br/>NO category shown]
    S -- yes --> I[CNN inference<br/>softmax over 5 DR grades]
    I --> UC{Uncertainty logic<br/>confidence, margin, entropy}
    UC -- indecisive --> D2[Decision: uncertain<br/>NO category shown]
    UC -- decisive --> D3[Decision: reported<br/>category + softmax confidence<br/>+ next step]
    D3 --> G[Grad-CAM<br/>from the loaded model]
    G --> R
    D1 --> R[Report generator<br/>PDF / HTML / CSV<br/>with limitations]
    D2 --> R
    D3 --> R
    R --> OUT[Download by user]
```

## Components

| Module | Responsibility | Key safety property |
|---|---|---|
| `src/privacy.py` | Validate and decode uploads, anonymous reference | Rejects spoofed/corrupt/oversize files; keeps only pixels |
| `src/image_quality.py` | Heuristic suitability checks | Labelled heuristic; `fail` blocks the model |
| `src/preprocessing.py` | Crop/pad/resize/normalise | One implementation for train and inference |
| `src/model_loader.py` | Build architectures, load checkpoint | Never raises; `weights_only`; smoke-test checkpoints blocked |
| `src/inference.py` | Orchestrate a screening | Prediction exists only if a real model produced it |
| `src/uncertainty.py` | Report vs abstain decision | Configurable thresholds; no false reassurance text |
| `src/explainability.py` | Grad-CAM | Computed from the loaded model's gradients; errors become messages |
| `src/report_generator.py` | HTML / PDF / CSV | Contains only produced results; escapes text |
| `training/*` | Data loading, training, evaluation | Patient-level split if possible; leakage check; test untouched |
| `app.py` | Streamlit UI (5 pages) | Shows only real model status and real evaluation files |

## Model states

`configured` -> predictions allowed. `unconfigured` (no file) / `demo_only` (smoke-test checkpoint) / `error`
(corrupt, wrong architecture, unsafe pickle) -> all produce the same outcome: no category, clear message.

## Data flow and storage

All data live in process memory for the duration of a session. The only files the system writes are produced by the
*training/evaluation scripts* (checkpoint, history, metrics JSON, plots, split CSVs) - never by the app on upload.

## Feature status

| Status | Features |
|---|---|
| **Implemented and covered by automated tests** (116 tests, synthetic data, Linux/Python 3.13) | Upload validation; quality heuristics; preprocessing; model loading incl. missing/corrupt/unsafe/smoke checkpoints; inference plumbing (ResNet18 and EfficientNet-B0, random weights); Grad-CAM mechanics on both architectures; uncertainty/abstention logic; HTML/PDF/CSV reports; metric calculations against hand-computed values; training and evaluation scripts end-to-end on tiny synthetic data incl. reproducibility and leakage check; all app pages render (headless); "writes no files" check |
| **Verified manually** | Streamlit server starts and answers its health endpoint |
| **Implemented but untested** | Windows `.ps1` scripts; ImageNet-pretrained download path (`--pretrained`; network blocked in the build sandbox, fallback message exists); GPU training; Ben-Graham preprocessing beyond shape checks; GitHub Actions workflow (never run); Streamlit Cloud deployment; interactive file-upload widget and batch tab in a real browser; visual appearance/responsiveness in real browsers; Python 3.11/3.12 |
| **Requires weights and/or a dataset (cannot work until you supply them)** | Any real prediction; real heatmaps on retinal images; every number on the evaluation page; abstention-threshold tuning; calibration assessment; external validation |
| **Planned (not built)** | Temperature-scaling calibration; validated image-quality classifier; out-of-distribution detector; macular-oedema grading; multi-dataset training; model-download from secure storage; multilingual UI |
| **Needs further research / clinical validation** | Any claim about real-world accuracy, safety or benefit; prospective study with ophthalmologists; regulatory pathway; fairness across populations and cameras |
