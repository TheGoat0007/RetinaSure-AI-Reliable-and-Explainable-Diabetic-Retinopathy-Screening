# Demo script (about 4-5 minutes)

Run locally: `python -m streamlit run app.py`. Rehearse once beforehand. Use only images you are entitled to show
(e.g. images from the dataset you trained with, if its terms allow display; never real patient photos from elsewhere).

**Two versions depending on whether you have trained a model.** Be upfront about which one you are showing.

## 0:00 - Home (30 s)

"RetinaSure AI is a screening *aid* for diabetic retinopathy. It's a prototype - not a diagnosis tool, and the banner says so."
Point at the model-status badge in the sidebar: **configured** (you trained one) or **"Model not configured"** (not yet).

## 0:30 - Safety first: reject bad input (45 s)

Image Screening -> upload a `.txt` file renamed `.png` -> rejected with a clear message.
"Uploads are checked by their real contents, not their names, and processed in memory."
Upload a very dark or blurred image -> quality table shows the failing check -> **Run analysis** -> "Image not suitable;
model was not run."
"A bad photo gets *no answer*, not a wrong answer. These checks are heuristics, and the app says so."

## 1:15 - A good image (90 s)

Upload a proper fundus photograph from your training dataset's licensed images.

* **If model configured:** show the severity category and "softmax confidence" with its caveat; open the probability expander; show the **Grad-CAM side-by-side** and the legend. "Red means the model leaned on that region - it's where it looked, not a lesion map."
* **If not configured:** show that quality passes and the app states "Model not configured - no prediction shown". "We could have shown a fake result here; we deliberately don't."

## 2:45 - Abstention (30 s)

If you have a borderline image, show the "uncertain - no category given" outcome. Otherwise explain the three
thresholds (confidence, margin, entropy) and that they're tuned on validation data (`docs/SAFETY_AND_LIMITATIONS.md`).

## 3:15 - Evidence (45 s)

Model & Evaluation page. *With a model:* sensitivity for referable DR with its confidence interval, the confusion
matrix, class imbalance, and your **external-dataset** result. *Without:* the page says **"Not yet evaluated"** -
"no invented numbers". Mention the leakage check and that the test set was never used for training.

## 4:00 - Report and limits (30 s)

Results -> download the PDF. "Every report carries the limitations and recommends a professional exam." Mention
privacy: anonymous reference code, filename off by default, images in memory only (when run locally).

## 4:30 - Close

"What we built is a tested, honest pipeline. What we haven't done is clinical validation - that's the future work."

## Likely questions - truthful answers

| Question | Answer |
|---|---|
| How accurate is it? | Give **only** your measured test and external numbers with the dataset named, or "not yet evaluated". Never a number you did not measure. |
| Can doctors use it? | No. It is an educational prototype; it would need clinical validation and regulatory approval. |
| Why not just show a confidence score? | Softmax is not a calibrated probability; we abstain on weak outputs and say so. |
| Is the heatmap showing the disease? | No, it shows where the model looked. It can highlight normal structures. |
| What happens to uploaded images? | Locally: stay in memory, nothing logged. Hosted: sent to the host's server. |
| Did you test it? | 116 automated tests with synthetic data for the software; real-image performance is whatever your evaluation file says. |
| Original contribution? | The trust layer: quality gate, abstention, honest failure states, evaluation protocol. |

## Backup plan

If the model or network fails, demo the rejection, quality and "Model not configured" paths - they need no model and
are part of the safety story.
