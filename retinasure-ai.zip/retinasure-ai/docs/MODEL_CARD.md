# Model card: RetinaSure AI DR grader

> **Status: no trained model is included in this repository.** This card describes the model *design* and what a
> trained checkpoint will record. Sections marked **[fill in after training]** must be completed from your real
> `models/evaluation_metrics.json`. Do not write numbers here that did not come from that file.

## Intended use

* Educational demonstration and research-assisted exploration of automated DR grading from colour fundus photographs.
* Users: students, teachers, researchers.

## Out-of-scope use

Clinical diagnosis, treatment decisions, replacing a dilated eye examination, screening real patients, any use on
images that are not colour fundus photographs (OCT, widefield/ultra-widefield, infrared, smartphone photos of screens).

## Model details

| Item | Value |
|---|---|
| Task | 5-class ordinal-scale classification: 0 No DR, 1 Mild NPDR, 2 Moderate NPDR, 3 Severe NPDR, 4 Proliferative DR |
| Default architecture | EfficientNet-B0 (torchvision), new 5-way head with dropout 0.3, ~4.0 M parameters, checkpoint ~16.4 MB |
| Alternative | ResNet18, ~11.2 M parameters, ~44.8 MB |
| Input | Square RGB, default 224 px (stored in the checkpoint) |
| Preprocessing | Crop black border, pad to square, resize; optional Ben Graham colour normalisation. Identical code for training and inference (`src/preprocessing.py`) |
| Framework | PyTorch |
| Initialisation | ImageNet-pretrained if `--pretrained` succeeded (recorded in checkpoint as `imagenet_pretrained`) |
| Loss | Cross-entropy, inverse-frequency class weights (default) |
| Selection | Best validation quadratic weighted kappa |
| Explainability | Grad-CAM on the last convolutional block |
| Uncertainty | Abstain when top probability, margin to runner-up, or normalised entropy cross configurable thresholds; uncalibrated softmax |

## Training data

**[fill in after training]** - dataset name, source, number of images, class counts, split sizes and whether the split
was patient-level are recorded automatically in the checkpoint and shown on the app's Model & Evaluation page.
Candidate datasets, access steps and licence cautions: `DATASET_GUIDE.md`.

## Evaluation methodology

* Stratified train / validation / test split; patient-level if IDs exist. Test split untouched during training.
* `training/evaluate.py` reports accuracy; macro precision/recall/F1 (over classes present); per-class precision, recall, support; confusion matrix; one-vs-rest ROC-AUC (undefined classes are reported as undefined, not zero); quadratic weighted kappa; sensitivity/specificity with 95% Wilson intervals for two binary endpoints (**any DR** = grade >= 1, **referable DR** = grade >= 2); expected calibration error; risk-coverage table.
* It refuses to run on a CSV that overlaps the train/validation CSVs beside it.
* Thresholds for abstention must be chosen on the validation split, never on the test split.

## Results

**Not yet evaluated.** **[fill in after training: paste the real values from `evaluation_metrics.json`, plus results on an external dataset.]**

## Class imbalance and false negatives

DR datasets are dominated by "No DR". A model can reach high accuracy while missing most severe cases. A false negative
(diseased eye graded as healthy) can delay care, so report sensitivity for referable DR with its confidence interval,
read the confusion matrix, and do not quote accuracy alone.

## Known limitations

* One dataset's performance does not establish clinical validity: cameras, populations, grading standards and prevalence differ between sites.
* Softmax confidence is not a calibrated probability; ECE is reported but measured on a single split.
* Quality checks are heuristics, not a validated gradability model; there is no out-of-distribution detector, so a non-fundus image that passes the colour/field-of-view heuristics would still be fed to the model.
* Grad-CAM shows model attention, not lesions; it can highlight the optic disc or vessels.
* No clinical validation, regulatory review, or prospective study has been performed.
* The model sees one photograph; it cannot assess other eye disease or the patient's history.

## Ethical considerations

Health imaging data requires care: use only data you are permitted to use, never upload patient images to public
demos, and make clear to every audience that this is a student prototype.
