# Dataset guide

**No dataset is included in this repository, and none may be redistributed through it.** Having access to a dataset
is not the same as having permission to republish it. Always read the provider's current terms yourself; the notes
below are a starting point, not legal advice.

## Verification status of this guide

The author's build environment could not reach Kaggle or Hugging Face, so licence texts for Kaggle-hosted data were
**not read directly**. What was checked is stated for each dataset.

## Options

### 1. APTOS 2019 Blindness Detection (suggested for training)

* **What:** Colour fundus photographs from Aravind Eye Hospital (India), graded 0-4 for DR severity. The public training set is commonly reported as about 3,662 labelled images. A third-party mirror also lists ~3.66k training rows, consistent with that.
* **Class balance (commonly reported, verify on your copy):** roughly 1805 No DR, 370 Mild, 999 Moderate, 193 Severe, 295 Proliferative - heavily imbalanced, which is why training uses class weights and why per-class metrics matter.
* **Access:** Kaggle competition "APTOS 2019 Blindness Detection": create a Kaggle account, join the competition and accept its rules, then download `train.csv` and `train_images`.
* **Licence/terms:** governed by the **competition rules** on Kaggle. *Not verified here.* A Hugging Face mirror labels itself MIT, but that is the uploader's claim, not the original provider's terms - do not rely on it.
* **Patient IDs:** none are provided, so splits are image-level. Near-duplicate images of one patient could therefore straddle train/test and flatter results; say this in your presentation.
* **Layout:** `data/aptos/train.csv` (`id_code,diagnosis`) and `data/aptos/train_images/<id_code>.png`.

### 2. IDRiD - Indian Diabetic Retinopathy Image Dataset (suggested as an *external* test set)

* **What (verified from the IEEE DataPort page):** from the ISBI 2018 challenge; 516 images for disease grading (413 train / 103 test) with DR grade and macular-oedema grade CSVs; plus lesion segmentation and localisation parts.
* **Access (verified):** IEEE DataPort, free IEEE account (IEEE membership not required, per the page). The page also mentions a subscription requirement for some access, so the exact terms are unclear.
* **Licence (verified):** the page **does not state a specific licence**. A dataset author's forum comment says academic use is allowed. Check the DataPort terms before any other use.
* **Use here:** too small to train a strong model alone, but ideal to measure how a model trained on APTOS performs on a *different* source. Prepare it with:
  `python training/dataset.py --csv <grading csv> --image-dir <images> --id-col "<id column>" --label-col "<DR grade column>" --output data/external/idrid.csv`
  (Open the CSV to see its exact column names.) Then run `training/evaluate.py` on it.

### 3. EyePACS / Kaggle "Diabetic Retinopathy Detection" (2015)

* Large (tens of thousands of images). Access is via Kaggle competition rules; the terms were **not verified** here. Heavy for a laptop.

## Why external validation matters

A model scoring well on a held-out slice of APTOS has only shown it works on APTOS-like data (same hospital, cameras,
grading practice). Reporting the drop (or lack of one) on IDRiD is far more honest and impressive than a single
high number. See `docs/MODEL_CARD.md`.

## Preparing data

1. Put files in the layout shown above (any folder names work; pass them with `--csv` / `--image-dir`).
2. `train.py` validates labels (0-4), reports missing images, and writes `data/splits/{train,val,test}.csv`.
3. Never edit the split CSVs by hand after training; `evaluate.py` refuses a test file that overlaps train/val.
4. Do not commit `data/` (it is git-ignored) and do not share images from restricted datasets.

## Ethics

Retinal photographs are health data. Even "anonymised" datasets must be used only under their terms. Do not upload
dataset images to public demo sites or third-party tools.
