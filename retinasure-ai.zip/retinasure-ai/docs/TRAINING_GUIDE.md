# Training guide (including free GPUs)

Training EfficientNet-B0 on a few thousand fundus images is realistic on a free GPU and slow on a laptop CPU.
*No training time estimates are given because none were measured.*

## Quick trial first (CPU is fine)

Prove the pipeline works on your machine before a long run:

```powershell
python training/train.py --csv data/aptos/train.csv --image-dir data/aptos/train_images `
    --dataset-name "APTOS 2019 (Kaggle)" --epochs 1 --img-size 128 --batch-size 16 --smoke-test `
    --output models/smoke.pt --splits-dir data/splits_trial
```

`--smoke-test` marks the checkpoint as **not usable for predictions** (the app shows "Demo mode"), so a trial
can never be mistaken for a real model.

## Real run

```powershell
python training/train.py --csv data/aptos/train.csv --image-dir data/aptos/train_images `
    --dataset-name "APTOS 2019 (Kaggle)" --epochs 15 --pretrained --version "v1"
```

Options worth knowing: `--arch resnet18` (lighter), `--img-size 256` (more detail, slower), `--preprocess ben_graham`
(colour normalisation; must match at inference - it is stored in the checkpoint automatically), `--seed`,
`--no-class-weights`, `--patient-col` (if your dataset has patient IDs).

## Using a free GPU (Kaggle Notebook or Google Colab)

*Written from general knowledge of these platforms; not tested by the author.*

1. Create a notebook and enable a GPU accelerator in its settings.
2. Get the project in: upload the project folder as a zip / dataset, or `git clone` your GitHub repository.
3. Add the APTOS data (in a Kaggle notebook, attach the competition data; in Colab, upload it or mount your Drive).
4. In a notebook cell: `!pip install -r requirements.txt` (the GPU build of PyTorch is usually preinstalled; if so, remove the `torch`/`torchvision` lines first), then run the `train.py` and `evaluate.py` commands above with `!python ...`, adjusting paths.
5. Download `retinasure_dr.pt`, `evaluation_metrics.json` and the small `.png/.json` files into your local `models/` folder.

## After training

1. `python training/evaluate.py --checkpoint models/retinasure_dr.pt --csv data/splits/test.csv`
2. (Recommended) evaluate on an external dataset (see `DATASET_GUIDE.md`).
3. `python training/evaluate.py ... --csv data/splits/val.csv --role val`, then read `risk_coverage` in
   `models/evaluation_metrics_val.json` to choose abstention thresholds.
4. Restart the app. The Model & Evaluation page now shows your real numbers.

## Reproducibility

Seeds are fixed and the pipeline was tested for identical weights across two runs on CPU with the same seed.
GPU runs may differ slightly (non-deterministic kernels).
