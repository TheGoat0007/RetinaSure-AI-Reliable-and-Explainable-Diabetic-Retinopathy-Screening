# Project summary - RetinaSure AI (PS-068)

*Edit the bracketed placeholders. Do not add numbers, partners or results that you did not obtain yourself.*

**Team:** [your name] | **School:** [school] | **Mentor:** [mentor]

## Problem

People with diabetes are at risk of diabetic retinopathy (DR), damage to the retina's blood vessels that can cause
irreversible vision loss if found late. Regular retinal screening is recommended, but it depends on trained
specialists and equipment, which are scarce in many places. Early-stage DR usually causes no symptoms, so people
often do not know they need care. *[Add a current, cited statistic here, e.g. from the IDF Diabetes Atlas or ICMR.
This project deliberately does not quote numbers it could not verify.]*

## Proposed solution

RetinaSure AI is a screening **aid** that looks at one retinal photograph and (1) refuses unusable images, (2) grades
DR severity on the standard 5-level scale with a trained deep-learning model, (3) shows which image regions
influenced the model, (4) **abstains** when it is not decisive, and (5) produces a report that states its limitations and
recommends professional examination.

## Target users

Students and researchers exploring trustworthy medical AI; as a longer-term direction, health workers who triage
photographs for referral *only after* proper clinical validation and regulatory approval (not part of this project).

## What is novel (honestly stated)

Not a new model architecture. The contribution is the **trust layer** around a standard CNN: heuristic gradability
gate, configurable abstention, explicit "no model -> no prediction" behaviour, evaluation that reports sensitivity with
confidence intervals and calibration error, a leakage check, safe checkpoint loading, and a test suite that proves
the failure modes behave. Many demos show only an accuracy number; this one is built to show when *not* to answer.

## Feasibility

Runs on a laptop CPU for inference; EfficientNet-B0 checkpoint is ~16 MB. Uses open-source tools only. Training is
feasible on a free GPU notebook. All software is built and tested; **the trained model and its results depend on
the student running training** (`docs/TRAINING_GUIDE.md`).

## Social impact (potential, not demonstrated)

If clinically validated in future, such tools could help prioritise who needs an ophthalmologist sooner. Today the
project's impact is educational. No pilots, users, partnerships or outcomes exist and none are claimed.

## Technical approach

PyTorch EfficientNet-B0 transfer learning on a public DR dataset (e.g. APTOS 2019); class-weighted loss; validation-
based checkpoint selection; Grad-CAM; softmax-based abstention; OpenCV heuristics for quality; Streamlit UI;
reportlab PDF. See `TECHNICAL_ARCHITECTURE.md` and `MODEL_CARD.md`.

## Results

**[Fill in from your real `evaluation_metrics.json`: dataset, test-set size, QWK, sensitivity/specificity for referable
DR with intervals, and the external-validation numbers. Until then write: "not yet evaluated".]**

## Future scope

Calibration (temperature scaling), a learned gradability classifier, out-of-distribution detection, macular-oedema
grading, training on several datasets, fairness analysis across cameras and populations, review by ophthalmologists,
and only then a prospective study and regulatory consultation.
