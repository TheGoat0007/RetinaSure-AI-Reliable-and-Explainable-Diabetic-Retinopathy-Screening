# Safety, privacy and limitations

## Safety design principles (all implemented and unit-tested)

1. **No model, no prediction.** If no valid checkpoint is loaded the app shows "Model not configured". There is no fallback to random or hard-coded outputs. Smoke-test checkpoints are blocked ("Demo mode").
2. **Bad image, no result.** If a quality check *fails*, the model is not run and no category is shown.
3. **Uncertain, no category.** Predictions that are not decisive are replaced by an abstention message and a recommendation to see a professional. Heatmaps are not drawn for abstained cases.
4. **No false reassurance.** Even a "No DR" output says this does not rule out DR and tells the user to keep to their screening schedule. Every outcome repeats that advice.
5. **Honest labelling.** Confidence is labelled "softmax confidence, not a calibrated clinical probability". Quality checks are labelled heuristic. Heatmaps are labelled "where the model looked, not where disease is".
6. **Nothing invented.** Metrics shown in the app come only from `evaluation_metrics.json`; if absent: "Not yet evaluated". Metrics belonging to a different checkpoint, or to a smoke test, trigger visible warnings.

## Abstention thresholds: how they are set

Defaults in `src/uncertainty.py` (`min_confidence=0.60`, `min_margin=0.15`, `max_normalized_entropy=0.80`) are
**placeholders chosen for reasonable behaviour, not tuned on data**. To choose them properly:

1. Train a model.
2. Run `python training/evaluate.py --checkpoint models/retinasure_dr.pt --csv data/splits/val.csv --role val`.
3. Open `models/evaluation_metrics_val.json` -> `risk_coverage.by_min_confidence`. Each row shows what fraction of images would still get a category (coverage) and how accurate those are.
4. Pick the loosest confidence cut-off whose accuracy on reported cases (and, importantly, sensitivity for referable DR) you consider acceptable, and set the three values accordingly.
5. Confirm on the **test** split once, and report coverage and accuracy honestly. If you change thresholds after looking at test results, say so.

Softmax confidence is frequently over-confident. Expected calibration error is reported, but a low ECE on one dataset
does not make the number a clinical probability, and nothing in this project claims calibration.

## Image-quality heuristics

Thresholds (`QualityThresholds` in `src/config.py`) are initial values from general image-sharpness/brightness
practice and were **only exercised on synthetic images**. On real photographs they may be too strict or too lax.
Before relying on them, run the quality module over a sample of your real images and adjust. A "pass" does not mean a
photograph is gradable; a "fail" may occasionally reject a usable photograph.

## Privacy: what actually happens

| Aspect | Behaviour |
|---|---|
| Upload handling | Bytes are validated and decoded in memory. The app's own code writes nothing to disk (tested for validation, screening and report generation). Streamlit holds uploaded files in server memory for the session. |
| Metadata | Only pixels are kept; EXIF/ICC/comments are discarded on decode. |
| Identifiers | No name, DOB or patient ID is requested. Reports carry `RS-` + first 10 hex chars of the image's SHA-256. The original filename is included only if the user ticks a box. |
| Logging | The app does not log image contents. |
| Transmission | Running locally, nothing leaves your computer (the app does not call external services). **When hosted, the image is sent to the host's server**; the host's infrastructure logs and policies apply and were not audited here. |
| Reports | Downloaded reports can embed retinal images (can be turned off). Treat them as health data. |
| Not done | No encryption beyond what the host provides, no user accounts, no audit trail, no consent flow. |

## Security measures implemented

Extension allow-list; real-file-type check by magic bytes; extension/content consistency; size limit (10 MB, also in
`.streamlit/config.toml`); pixel-count limit against decompression bombs; full decode with errors caught; model
checkpoints loaded with `torch.load(weights_only=True)` (tested: a malicious pickle is refused and not executed);
HTML report escapes all dynamic text (tested); no credentials anywhere in the code.

Not covered: denial-of-service protection, authentication, rate limiting, a security audit.

## Limitations

See `KNOWN_LIMITATIONS.md` for the full verified/unverified breakdown.

## What a professional evaluation provides that this cannot

Dilated examination, optical coherence tomography, visual acuity, history and clinical judgement. If you have
diabetes, keep regular eye examinations whatever this prototype shows. Sudden vision loss, flashes, new floaters or a
dark curtain over the vision need urgent medical care.
