"""Building, saving and loading model checkpoints.

Checkpoint (single .pt file, always loaded with torch.load(weights_only=True)):

    state_dict, arch, num_classes, img_size, class_names   (required)
    preprocess ("crop_resize" | "ben_graham"), version, dataset_name, created, notes, seed, epochs,
    best_epoch, patient_level_split, pretrained, smoke_test                (optional, plain values only)

load_model() NEVER raises. It returns a LoadedModel whose `status` is one of:
    "configured"   valid checkpoint, usable for predictions
    "unconfigured" no checkpoint file at the expected path
    "error"        file exists but is unreadable / incompatible
    "demo_only"    checkpoint was produced by `train.py --smoke-test` (pipeline test): NOT usable
Only "configured" is `usable`. The app never fabricates predictions for any other state.
"""
from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from . import config

logger = logging.getLogger("retinasure")

_OPTIONAL_META = ("version", "dataset_name", "created", "notes", "seed", "epochs", "best_epoch",
                  "patient_level_split", "pretrained", "smoke_test", "n_train", "n_val", "n_test",
                  "class_weights", "lr", "batch_size", "val_qwk")


@dataclass
class LoadedModel:
    status: str
    message: str
    model: Any = None
    arch: str = ""
    img_size: int = config.DEFAULT_IMG_SIZE
    preprocess: str = "crop_resize"
    class_names: list[str] = field(default_factory=lambda: list(config.CLASS_NAMES))
    meta: dict[str, Any] = field(default_factory=dict)
    path: str = ""

    @property
    def usable(self) -> bool:
        return self.status == "configured" and self.model is not None

    @property
    def info(self) -> dict[str, Any]:
        m = self.meta
        return {"arch": self.arch, "img_size": self.img_size, "preprocess": self.preprocess,
                "version": m.get("version", "unknown"), "dataset": m.get("dataset_name", "not recorded"),
                "created": m.get("created", "unknown"), "sha256": m.get("sha256", ""), "notes": m.get("notes", "")}


def build_model(arch: str, num_classes: int = config.NUM_CLASSES, pretrained: bool = False):
    """Create a torchvision network with a fresh classification head."""
    import torch.nn as nn
    import torchvision.models as tvm

    if arch not in config.SUPPORTED_ARCHS:
        raise ValueError(f"Unsupported architecture '{arch}'. Supported: {config.SUPPORTED_ARCHS}")
    if arch == "resnet18":
        net = tvm.resnet18(weights=tvm.ResNet18_Weights.IMAGENET1K_V1 if pretrained else None)
        net.fc = nn.Linear(net.fc.in_features, num_classes)
    elif arch == "resnet50":
        net = tvm.resnet50(weights=tvm.ResNet50_Weights.IMAGENET1K_V2 if pretrained else None)
        net.fc = nn.Linear(net.fc.in_features, num_classes)
    else:
        net = tvm.efficientnet_b0(weights=tvm.EfficientNet_B0_Weights.IMAGENET1K_V1 if pretrained else None)
        net.classifier[1] = nn.Linear(net.classifier[1].in_features, num_classes)
    return net


def gradcam_target_layer(model, arch: str):
    """Last convolutional stage: the standard Grad-CAM target for the supported architectures."""
    if arch in ("resnet18", "resnet50"):
        return model.layer4[-1]
    if arch == "efficientnet_b0":
        return model.features[-1]
    raise ValueError(f"No Grad-CAM target layer is defined for '{arch}'.")


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def save_checkpoint(path: Path | str, model, arch: str, img_size: int, preprocess: str, **extra: Any) -> None:
    import torch

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "state_dict": {k: v.detach().cpu() for k, v in model.state_dict().items()},
        "arch": arch, "num_classes": config.NUM_CLASSES, "class_names": list(config.CLASS_NAMES),
        "img_size": int(img_size), "preprocess": preprocess,
        "created": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    payload.update(extra)
    torch.save(payload, path)


def load_model(path: Path | str | None = None) -> LoadedModel:
    """Load a checkpoint; always returns a LoadedModel (see module docstring)."""
    path = Path(path) if path else Path(config.DEFAULT_MODEL_PATH)
    if not path.is_file():
        return LoadedModel("unconfigured",
                           f"Model not configured: no trained checkpoint was found at '{path.parent.name}/{path.name}'. Train one with "
                           "training/train.py (see the README) and place it there. Until then the app runs in demo mode "
                           "and gives no clinical prediction.", path=str(path))
    try:
        import torch

        if path.stat().st_size > config.MAX_CHECKPOINT_MB * 1024 * 1024:
            return LoadedModel("error", f"Model file is larger than {config.MAX_CHECKPOINT_MB} MB; refusing to load it.", path=str(path))
        try:
            ck = torch.load(path, map_location="cpu", weights_only=True)
        except Exception as exc:  # corrupted file, wrong format, or a pickle that tried to run code
            logger.warning("Checkpoint load failed: %s", type(exc).__name__)
            return LoadedModel("error", f"The model file could not be read safely ({type(exc).__name__}).", path=str(path))
        if not isinstance(ck, dict):
            return LoadedModel("error", "Checkpoint has an unexpected structure.", path=str(path))
        missing = [k for k in ("state_dict", "arch", "img_size", "class_names") if k not in ck]
        if missing:
            return LoadedModel("error", f"Checkpoint is missing required fields: {', '.join(missing)}.", path=str(path))
        if list(ck["class_names"]) != config.CLASS_NAMES or ck.get("num_classes", config.NUM_CLASSES) != config.NUM_CLASSES:
            return LoadedModel("error", "Checkpoint classes do not match the 5-class DR scheme used by this app.", path=str(path))
        try:
            img_size = int(ck["img_size"])
            if not 32 <= img_size <= 1024:
                raise ValueError
        except (TypeError, ValueError):
            return LoadedModel("error", "Checkpoint img_size is invalid (expected 32-1024).", path=str(path))
        preprocess = ck.get("preprocess", "crop_resize")
        try:
            net = build_model(ck["arch"], config.NUM_CLASSES, pretrained=False)
            net.load_state_dict(ck["state_dict"], strict=True)
        except Exception:
            return LoadedModel("error", "Checkpoint weights do not match the declared architecture.", path=str(path))
        net.eval()
        meta = {k: ck[k] for k in _OPTIONAL_META if k in ck}
        meta["sha256"] = _sha256(path)
        smoke = bool(ck.get("smoke_test", False))
        return LoadedModel(
            "demo_only" if smoke else "configured",
            "Demo mode: this checkpoint came from a pipeline smoke test (random or barely trained weights) and cannot be "
            "used for predictions." if smoke else "Trained model loaded.",
            model=net, arch=ck["arch"], img_size=img_size, preprocess=preprocess,
            class_names=list(ck["class_names"]), meta=meta, path=str(path))
    except Exception as exc:  # last-resort guard: loading must never crash the app
        logger.warning("Unexpected model-loading error: %s", type(exc).__name__)
        return LoadedModel("error", f"The model could not be loaded ({type(exc).__name__}).", path=str(path))
