"""Screening reports: HTML, PDF (reportlab) and CSV.

Reports contain only what the pipeline actually produced. They never ask for or include a patient name,
date of birth or patient ID. The uploaded filename is excluded unless the caller passes it explicitly,
and it is always escaped.
"""
from __future__ import annotations

import base64
import csv
import io
from html import escape
from typing import Optional
from xml.sax.saxutils import escape as xml_escape

import cv2
import numpy as np

from . import config, uncertainty
from .explainability import HEATMAP_LEGEND
from .inference import ScreeningResult

CSV_FIELDS = ["reference", "timestamp", "decision_status", "image_quality", "predicted_class", "confidence",
              "next_step", "model_version", "model_checkpoint_sha256_prefix"]

PRIVACY_LINE = "No patient name, date of birth or patient ID is collected or included in this report."

LIMITATIONS = [
    "RetinaSure AI is an educational and research prototype, not a medical device.",
    "Its output is not a confirmed medical diagnosis and does not replace an eye-care professional.",
    "A No DR output, or the absence of any result, does NOT rule out diabetic retinopathy; the model can miss disease.",
    "Model scores are softmax outputs, not calibrated clinical probabilities.",
    "Image-quality checks are simple heuristics, not a validated clinical gradability model.",
    "Heat-maps show where the model looked; they are not a lesion map or proof of disease.",
    "Performance on one dataset does not establish performance on other cameras, populations or clinics.",
]

FOLLOW_UP = ("Regardless of this output, follow diabetic eye-screening guidance from your clinician. Seek urgent medical "
             "care for sudden vision loss, a curtain or shadow over your vision, or a sudden shower of new floaters.")


def _png(rgb: np.ndarray) -> bytes:
    ok, buf = cv2.imencode(".png", cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))
    return buf.tobytes() if ok else b""


def _images(r: ScreeningResult) -> Optional[tuple[bytes, bytes]]:
    if r.decision.has_prediction and r.explain is not None and r.explain.available and r.processed is not None:
        return _png(r.processed), _png(r.explain.overlay)
    return None


def _model_rows(r: ScreeningResult) -> list[tuple[str, str]]:
    if r.model_status != "configured":
        return [("Model status", {"unconfigured": "Not configured (no clinical prediction available)",
                                  "demo_only": "Pipeline-test checkpoint (demo only; no prediction)",
                                  "error": "Could not be loaded (no prediction)"}.get(r.model_status, r.model_status))]
    i = r.model_info
    return [("Architecture", str(i.get("arch", ""))), ("Model version", str(i.get("version", ""))),
            ("Training data (as recorded)", str(i.get("dataset", ""))), ("Checkpoint SHA-256 (prefix)", str(i.get("sha256", ""))[:12])]


def _filename_rows(filename: Optional[str]) -> list[tuple[str, str]]:
    return [("Filename (included at your request)", filename)] if filename else []


def generate_html(r: ScreeningResult, filename: Optional[str] = None, include_images: bool = True) -> str:
    d = r.decision
    kv = lambda rows: "<table>" + "".join(f"<tr><th>{escape(a)}</th><td>{escape(b)}</td></tr>" for a, b in rows) + "</table>"

    if d.has_prediction and r.prediction is not None:
        probs = "".join(f"<tr><td>{escape(n)}</td><td>{p:.1%}</td></tr>" for n, p in zip(config.CLASS_NAMES, r.prediction.probs))
        result = (f"<p class='big'><strong>Model output:</strong> {escape(d.predicted_label)}</p>"
                  f"<p><strong>Softmax confidence:</strong> {d.confidence:.0%}. This is a model score, not a calibrated clinical probability.</p>"
                  f"<table><tr><th>Class</th><th>Model score</th></tr>{probs}</table>")
        if d.caution:
            result += "<p class='warn'>Image quality was flagged as questionable; treat this output with extra caution.</p>"
    else:
        result = (f"<p class='big'><strong>{escape(d.title)}</strong></p><p>No severity category is provided.</p>"
                  f"<p>{escape(d.message)}</p>")
    quality = "<p>Not available.</p>"
    q = r.quality
    quality = ("<table><tr><th>Check</th><th>Result</th><th>Value</th><th>Detail</th></tr>" + "".join(
        f"<tr><td>{escape(x['Check'])}</td><td>{x['Result']}</td><td>{x['Value']}</td><td>{escape(x['Detail'])}</td></tr>"
        for x in q.as_rows()) + f"</table><p><strong>Overall (heuristic):</strong> {escape(q.summary)}</p>"
        f"<p class='small'>{escape(q.note)}</p>")
    imgs = ""
    pair = _images(r) if include_images else None
    if pair:
        b64 = [base64.b64encode(x).decode() for x in pair]
        imgs = ("<h2>Explainability (Grad-CAM)</h2><div class='row'>"
                f"<figure><img alt='Image as seen by the model' src='data:image/png;base64,{b64[0]}'/><figcaption>Image as seen by the model</figcaption></figure>"
                f"<figure><img alt='Heat-map overlay' src='data:image/png;base64,{b64[1]}'/><figcaption>Grad-CAM overlay</figcaption></figure></div>"
                f"<p class='small'>{escape(HEATMAP_LEGEND)}</p>")
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><title>{config.APP_NAME} screening report</title>
<style>body{{font-family:Arial,Helvetica,sans-serif;color:#0B1F3A;max-width:880px;margin:24px auto;padding:0 16px;line-height:1.45}}
h1{{border-bottom:4px solid #0B7A85;padding-bottom:8px}}h2{{color:#0B7A85;margin-top:26px}}
table{{border-collapse:collapse;width:100%;margin:6px 0}}th,td{{border:1px solid #cbd5e1;padding:6px 8px;text-align:left;vertical-align:top}}
th{{background:#f1f5f9}}.box{{background:#FFF7E6;border:1px solid #F5C26B;border-left:6px solid #E0A100;padding:10px 14px;border-radius:6px}}
.big{{font-size:1.25rem}}.warn{{color:#9A5B00}}.small{{font-size:12px;color:#44546A}}.row{{display:flex;gap:12px}}
figure{{margin:0;flex:1}}img{{width:100%}}figcaption{{font-size:12px;text-align:center}}</style></head><body>
<h1>{config.APP_NAME}: screening report</h1>
<div class="box"><strong>{escape(config.SHORT_DISCLAIMER)}</strong> A normal-looking result does NOT rule out diabetic retinopathy.</div>
<h2>Analysis</h2>{kv([("Reference", r.anon_id), ("Date / time", r.timestamp), ("App version", config.APP_VERSION)] + _filename_rows(filename))}
<p class='small'>{escape(PRIVACY_LINE)}</p>
<h2>Result</h2>{result}
<p><strong>Suggested next step:</strong> {escape(d.next_step)}</p>
<h2>Image quality (heuristic checks)</h2>{quality}
<h2>Model</h2>{kv(_model_rows(r))}
{imgs}
<h2>Limitations</h2><ul>{''.join(f'<li>{escape(x)}</li>' for x in LIMITATIONS)}</ul>
<p><strong>{escape(FOLLOW_UP)}</strong></p></body></html>"""


def generate_pdf(r: ScreeningResult, filename: Optional[str] = None, include_images: bool = True) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import Image, KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    navy, teal, grid = colors.HexColor("#0B1F3A"), colors.HexColor("#0B7A85"), colors.HexColor("#cbd5e1")
    ss = getSampleStyleSheet()
    body = ParagraphStyle("b", parent=ss["BodyText"], fontSize=9.5, leading=13, textColor=navy)
    cell = ParagraphStyle("c", parent=body, fontSize=8.5, leading=11)
    h1 = ParagraphStyle("h1", parent=ss["Title"], fontSize=19, textColor=navy, alignment=0)
    h2 = ParagraphStyle("h2", parent=ss["Heading2"], fontSize=12.5, textColor=teal, spaceBefore=10)
    P = lambda t, s=body: Paragraph(xml_escape(str(t)), s)

    def grid_table(rows, widths, header=False):
        t = Table([[P(c, cell) for c in row] for row in rows], colWidths=[w * mm for w in widths])
        style = [("GRID", (0, 0), (-1, -1), 0.4, grid), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                 ("BACKGROUND", (0, 0), (-1, 0) if header else (0, -1), colors.HexColor("#f1f5f9"))]
        t.setStyle(TableStyle(style))
        return t

    d = r.decision
    story = [P(f"{config.APP_NAME}: screening report", h1)]
    box = Table([[P(config.SHORT_DISCLAIMER + " A normal-looking result does NOT rule out diabetic retinopathy.", cell)]],
                colWidths=[170 * mm])
    box.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.8, colors.HexColor("#E0A100")),
                             ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#FFF7E6"))]))
    story += [box, P("Analysis", h2),
              grid_table([("Reference", r.anon_id), ("Date / time", r.timestamp), ("App version", config.APP_VERSION)]
                         + _filename_rows(filename), [55, 115]),
              P(PRIVACY_LINE, cell), P("Result", h2)]
    if d.has_prediction and r.prediction is not None:
        story += [P(f"Model output: {d.predicted_label}", ParagraphStyle("big", parent=body, fontSize=13, leading=17)),
                  P(f"Softmax confidence: {d.confidence:.0%}. This is a model score, not a calibrated clinical probability."),
                  grid_table([("Class", "Model score")] + [(n, f"{p:.1%}") for n, p in zip(config.CLASS_NAMES, r.prediction.probs)],
                             [85, 85], header=True)]
        if d.caution:
            story.append(P("Image quality was flagged as questionable; treat this output with extra caution."))
    else:
        story += [P(d.title, ParagraphStyle("big", parent=body, fontSize=13, leading=17)),
                  P("No severity category is provided."), P(d.message)]
    story += [Spacer(1, 4), P("Suggested next step: " + d.next_step), P("Image quality (heuristic checks)", h2)]
    q = r.quality
    story += [grid_table([("Check", "Result", "Value", "Detail")] + [(x["Check"], x["Result"], x["Value"], x["Detail"])
                                                                   for x in q.as_rows()], [42, 18, 16, 94], header=True),
              Spacer(1, 3), P("Overall (heuristic): " + q.summary), P(q.note, cell), P("Model", h2),
              grid_table(_model_rows(r), [55, 115])]
    pair = _images(r) if include_images else None
    if pair:
        w = 82 * mm
        story.append(KeepTogether([
            P("Explainability (Grad-CAM)", h2),
            Table([[Image(io.BytesIO(pair[0]), w, w), Image(io.BytesIO(pair[1]), w, w)],
                   [P("Image as seen by the model", cell), P("Grad-CAM overlay", cell)]], colWidths=[85 * mm, 85 * mm]),
            P(HEATMAP_LEGEND, cell)]))
    story += [P("Limitations", h2)] + [P("- " + x) for x in LIMITATIONS] + [Spacer(1, 6), P(FOLLOW_UP)]
    buf = io.BytesIO()
    SimpleDocTemplate(buf, pagesize=A4, leftMargin=20 * mm, rightMargin=20 * mm, topMargin=16 * mm, bottomMargin=16 * mm,
                      title=f"{config.APP_NAME} screening report", author=config.APP_NAME).build(story)
    return buf.getvalue()


def generate_csv(results: list[ScreeningResult]) -> str:
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=CSV_FIELDS, lineterminator="\n")
    w.writeheader()
    for r in results:
        d = r.decision
        w.writerow({
            "reference": r.anon_id, "timestamp": r.timestamp, "decision_status": d.status, "image_quality": r.quality.status,
            "predicted_class": d.predicted_label or "" if d.has_prediction else "",
            "confidence": f"{d.confidence:.4f}" if d.has_prediction and d.confidence is not None else "",
            "next_step": d.next_step, "model_version": r.model_info.get("version", "") if r.model_status == "configured" else "",
            "model_checkpoint_sha256_prefix": str(r.model_info.get("sha256", ""))[:12] if r.model_status == "configured" else "",
        })
    return buf.getvalue()
