"""Image preprocessing shared by training and inference.

Training and inference must call the same functions with the same settings; the settings are stored
inside the checkpoint (see model_loader.py).
"""
from __future__ import annotations

import cv2
import numpy as np

from .image_quality import fov_mask

IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)
METHODS = ("crop_resize", "ben_graham")


def crop_to_fov(rgb: np.ndarray) -> np.ndarray:
    """Crop away the black border around the retinal disc. Unchanged if no disc is found."""
    h, w = rgb.shape[:2]
    s = 512 / max(h, w)
    small = rgb if s >= 1 else cv2.resize(rgb, (max(1, int(w * s)), max(1, int(h * s))), interpolation=cv2.INTER_AREA)
    mask = fov_mask(small)
    if mask.sum() < 0.05 * mask.size:
        return rgb
    ys, xs = np.where(mask)
    sy, sx = h / small.shape[0], w / small.shape[1]
    y0, y1 = int(ys.min() * sy), min(h, int(np.ceil((ys.max() + 1) * sy)))
    x0, x1 = int(xs.min() * sx), min(w, int(np.ceil((xs.max() + 1) * sx)))
    return rgb[y0:y1, x0:x1]


def _pad_square(img: np.ndarray) -> np.ndarray:
    h, w = img.shape[:2]
    side = max(h, w)
    out = np.zeros((side, side, 3), dtype=np.uint8)
    y0, x0 = (side - h) // 2, (side - w) // 2
    out[y0:y0 + h, x0:x0 + w] = img
    return out


def ben_graham(rgb: np.ndarray) -> np.ndarray:
    """Local-contrast enhancement popularised in the Kaggle DR competition (Ben Graham)."""
    blurred = cv2.GaussianBlur(rgb, (0, 0), max(rgb.shape[:2]) / 30.0)
    out = cv2.addWeighted(rgb, 4, blurred, -4, 128)
    h, w = out.shape[:2]
    circle = np.zeros((h, w), np.uint8)
    cv2.circle(circle, (w // 2, h // 2), int(min(h, w) * 0.48), 255, -1)
    return cv2.bitwise_and(out, out, mask=circle)


def preprocess_image(rgb: np.ndarray, img_size: int, method: str = "crop_resize") -> np.ndarray:
    """Return a square uint8 RGB image of shape (img_size, img_size, 3)."""
    if method not in METHODS:
        raise ValueError(f"Unknown preprocessing method '{method}'. Choose from {METHODS}.")
    if not isinstance(rgb, np.ndarray) or rgb.ndim != 3 or rgb.shape[2] != 3:
        raise ValueError("Expected an HxWx3 RGB image.")
    img = _pad_square(crop_to_fov(rgb.astype(np.uint8, copy=False)))
    interp = cv2.INTER_AREA if img.shape[0] > img_size else cv2.INTER_CUBIC
    img = cv2.resize(img, (img_size, img_size), interpolation=interp)
    return ben_graham(img) if method == "ben_graham" else img


def normalize(rgb_uint8: np.ndarray) -> np.ndarray:
    """uint8 HxWx3 -> float32 3xHxW, ImageNet-normalised."""
    x = (rgb_uint8.astype(np.float32) / 255.0 - np.array(IMAGENET_MEAN, np.float32)) / np.array(IMAGENET_STD, np.float32)
    return np.ascontiguousarray(x.transpose(2, 0, 1))


def to_tensor(rgb_uint8: np.ndarray):
    """uint8 HxWx3 -> torch float32 tensor of shape 1x3xHxW (torch imported lazily)."""
    import torch

    return torch.from_numpy(normalize(rgb_uint8)).unsqueeze(0)
