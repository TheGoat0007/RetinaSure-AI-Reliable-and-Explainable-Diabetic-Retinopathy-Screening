"""End-to-end screening pipeline: quality -> preprocess -> model -> uncertainty -> Grad-CAM.

A prediction exists ONLY if a real, usable model produced it. If the model is missing, unusable, fails, or
the image fails the quality checks, the Decision says so and no category is given.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

import cv2
import numpy as np

from . import config, uncertainty
from .explainability import ExplainResult, compute_gradcam
from .image_quality import QualityReport, assess_quality
from .model_loader import LoadedModel
from .preprocessing import preprocess_image, to_tensor
from .uncertainty import Decision, UncertaintyConfig, normalized_entropy

logger = logging.getLogger("retinasure")


class InferenceError(RuntimeError):
    """The model could not produce a valid output."""


@dataclass
class Prediction:
    probs: list[float]
    class_index: int
    confidence: float      # top-class softmax probability (uncalibrated)
    entropy: float         # normalised: 0 = certain, 1 = uniform


@dataclass
class ScreeningResult:
    anon_id: str
    timestamp: str
    quality: QualityReport
    decision: Decision
    model_status: str
    model_info: dict
    prediction: Optional[Prediction] = None
    explain: Optional[ExplainResult] = None
    original_preview: Optional[np.ndarray] = None
    processed: Optional[np.ndarray] = None
    inference_error: Optional[str] = None


def predict_unchecked(m: LoadedModel, processed_rgb: np.ndarray) -> Prediction:
    """Run the network even for demo-only checkpoints. Used by evaluation/tests; the app uses predict()."""
    import torch

    if m is None or m.model is None:
        raise InferenceError("No model is loaded.")
    try:
        with torch.no_grad():
            probs = torch.softmax(m.model(to_tensor(processed_rgb)), dim=1)[0].cpu().numpy()
    except Exception as exc:
        logger.warning("Inference failed: %s", type(exc).__name__)
        raise InferenceError(f"The model failed to process this image ({type(exc).__name__}).") from exc
    if probs.shape != (config.NUM_CLASSES,) or not np.isfinite(probs).all():
        raise InferenceError("The model returned an invalid output.")
    p = [float(x) for x in probs]
    k = int(np.argmax(p))
    return Prediction(p, k, p[k], float(normalized_entropy(p)))


def predict(m: LoadedModel, processed_rgb: np.ndarray) -> Prediction:
    """Predict with a usable (configured) model; raises InferenceError otherwise."""
    if m is None or not m.usable:
        raise InferenceError("No usable trained model is configured; refusing to produce a prediction.")
    return predict_unchecked(m, processed_rgb)


def _preview(rgb: np.ndarray, side: int = 512) -> np.ndarray:
    h, w = rgb.shape[:2]
    s = side / max(h, w)
    return rgb.copy() if s >= 1 else cv2.resize(rgb, (int(w * s), int(h * s)), interpolation=cv2.INTER_AREA)


def run_screening(rgb: np.ndarray, m: LoadedModel, anon_id: str, ucfg: UncertaintyConfig | None = None,
                  explain: bool = True) -> ScreeningResult:
    """Screen one decoded image. Never raises for model problems; they become part of the result."""
    ucfg = ucfg or UncertaintyConfig()
    quality = assess_quality(rgb)
    base = dict(anon_id=anon_id, timestamp=datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %Z"),
                quality=quality, model_status=m.status, model_info=m.info if m.status != "unconfigured" else {},
                original_preview=_preview(rgb))

    if not m.usable:
        return ScreeningResult(decision=uncertainty.decide(m.status, quality.status, None, ucfg), **base)
    if not quality.suitable:
        return ScreeningResult(decision=uncertainty.decide(m.status, quality.status, None, ucfg), **base)

    try:
        processed = preprocess_image(rgb, m.img_size, m.preprocess)
        pred = predict(m, processed)
    except (InferenceError, ValueError) as exc:
        return ScreeningResult(decision=uncertainty.decide("error", quality.status, None, ucfg),
                               inference_error=str(exc), **base)

    decision = uncertainty.decide(m.status, quality.status, pred.probs, ucfg)
    ex = compute_gradcam(m, processed, target_class=pred.class_index) if (explain and decision.has_prediction) else None
    return ScreeningResult(decision=decision, prediction=pred, explain=ex, processed=processed, **base)
