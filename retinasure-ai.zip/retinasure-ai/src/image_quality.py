"""Heuristic image-quality assessment for colour fundus photographs.

IMPORTANT: these are simple image-processing checks. They are NOT a validated clinical gradability
model. They catch obviously unsuitable inputs but will miss some ungradable images and may flag
some usable ones. Thresholds are provisional defaults (see THRESHOLDS) and were not tuned on real
retinal images.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import cv2
import numpy as np

NOTE = ("These checks are simple heuristics (size, exposure, sharpness, visible retina, colour). "
        "They are not a validated clinical image-quality model and cannot guarantee an image is gradable.")

THRESHOLDS = {
    "min_side_fail": 224, "min_side_warn": 512,
    "dark_fail": 25.0, "dark_warn": 40.0, "bright_warn": 200.0, "bright_fail": 225.0,
    "contrast_warn": 15.0,
    "blur_fail": 10.0, "blur_warn": 40.0,
    "fov_fail": 0.20, "fov_warn": 0.40, "fill_warn": 0.55,
    "saturation_fail": 0.10, "red_green_warn": 1.05,
}

_WORK = 512  # long side used for mask and sharpness computations (makes results resolution-independent)


@dataclass
class QualityCheck:
    name: str
    severity: str            # "ok" | "warn" | "fail"
    value: float | None
    detail: str

    @property
    def passed(self) -> bool:
        return self.severity == "ok"


@dataclass
class QualityReport:
    status: str              # "pass" | "warn" | "fail"
    checks: list[QualityCheck] = field(default_factory=list)
    summary: str = ""
    note: str = NOTE

    @property
    def suitable(self) -> bool:
        return self.status != "fail"

    def as_rows(self) -> list[dict]:
        return [{"Check": c.name, "Result": {"ok": "OK", "warn": "WARNING", "fail": "FAIL"}[c.severity],
                 "Value": "" if c.value is None else round(float(c.value), 2), "Detail": c.detail}
                for c in self.checks]


def _small(rgb: np.ndarray) -> np.ndarray:
    h, w = rgb.shape[:2]
    s = _WORK / max(h, w)
    return rgb if s >= 1 else cv2.resize(rgb, (max(1, int(w * s)), max(1, int(h * s))), interpolation=cv2.INTER_AREA)


def fov_mask(rgb: np.ndarray, threshold: int = 15) -> np.ndarray:
    """Boolean mask of the largest bright blob (the retinal disc), same size as the input."""
    gray = cv2.GaussianBlur(cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY), (5, 5), 0)
    binary = (gray > threshold).astype(np.uint8)
    k = max(3, int(min(gray.shape) * 0.01) | 1)
    ker = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    binary = cv2.morphologyEx(cv2.morphologyEx(binary, cv2.MORPH_OPEN, ker), cv2.MORPH_CLOSE, ker)
    n, labels, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
    if n <= 1:
        return np.zeros(gray.shape, dtype=bool)
    return labels == (1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA])))


def assess_quality(rgb: np.ndarray, t: dict | None = None) -> QualityReport:
    """Run all heuristic checks on an RGB uint8 image."""
    t = {**THRESHOLDS, **(t or {})}
    if not isinstance(rgb, np.ndarray) or rgb.ndim != 3 or rgb.shape[2] != 3:
        return QualityReport("fail", [QualityCheck("Valid colour image", "fail", None, "Not a 3-channel colour image.")],
                             "The input is not a usable colour image.")
    h, w = rgb.shape[:2]
    checks: list[QualityCheck] = []

    side = min(h, w)
    if side < t["min_side_fail"]:
        checks.append(QualityCheck("Resolution", "fail", side, f"Shorter side {side}px is too small; retinal detail is lost."))
    elif side < t["min_side_warn"]:
        checks.append(QualityCheck("Resolution", "warn", side, f"Shorter side {side}px is low; small lesions may be invisible."))
    else:
        checks.append(QualityCheck("Resolution", "ok", side, f"Shorter side {side}px."))

    small = _small(rgb)
    mask = fov_mask(small)
    frac = float(mask.mean())
    if frac < t["fov_fail"]:
        checks.append(QualityCheck("Retinal field of view", "fail", frac,
                                   "No clear retinal disc found; this may not be a fundus photograph."))
        mask = np.ones_like(mask, dtype=bool)  # so the remaining checks still report something
    else:
        ys, xs = np.where(mask)
        bw, bh = xs.max() - xs.min() + 1, ys.max() - ys.min() + 1
        fill, aspect = float(mask.sum() / (bw * bh)), bw / bh
        if frac < t["fov_warn"] or fill < t["fill_warn"] or not 0.6 <= aspect <= 1.8:
            checks.append(QualityCheck("Retinal field of view", "warn", frac, "Retinal field is small, cropped or oddly shaped."))
        else:
            checks.append(QualityCheck("Retinal field of view", "ok", frac, "A retinal disc was found."))

    gray = cv2.cvtColor(small, cv2.COLOR_RGB2GRAY).astype(np.float32)
    inside = gray[mask]
    mean_b, std_b = float(inside.mean()), float(inside.std())
    if mean_b < t["dark_fail"]:
        checks.append(QualityCheck("Brightness", "fail", mean_b, "Far too dark."))
    elif mean_b < t["dark_warn"]:
        checks.append(QualityCheck("Brightness", "warn", mean_b, "Rather dark."))
    elif mean_b > t["bright_fail"]:
        checks.append(QualityCheck("Brightness", "fail", mean_b, "Far too bright (over-exposed)."))
    elif mean_b > t["bright_warn"]:
        checks.append(QualityCheck("Brightness", "warn", mean_b, "Rather bright."))
    else:
        checks.append(QualityCheck("Brightness", "ok", mean_b, "Acceptable exposure."))

    if std_b < t["contrast_warn"]:
        checks.append(QualityCheck("Contrast", "warn", std_b, "Low contrast / washed out."))
    else:
        checks.append(QualityCheck("Contrast", "ok", std_b, "Acceptable contrast."))

    # Sharpness: variance of the Laplacian of the green channel, away from the disc edge.
    lap = cv2.Laplacian(small[:, :, 1], cv2.CV_64F)
    er = max(3, int(min(mask.shape) * 0.04))
    inner = cv2.erode(mask.astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (er, er))).astype(bool)
    if inner.sum() < 100:
        inner = mask
    sharp = float(lap[inner].var())
    if sharp < t["blur_fail"]:
        checks.append(QualityCheck("Sharpness", "fail", sharp, "Image appears severely blurred."))
    elif sharp < t["blur_warn"]:
        checks.append(QualityCheck("Sharpness", "warn", sharp, "Image may be blurred."))
    else:
        checks.append(QualityCheck("Sharpness", "ok", sharp, "Acceptable sharpness."))

    sat = float(cv2.cvtColor(small, cv2.COLOR_RGB2HSV)[:, :, 1][mask].mean() / 255.0)
    ratio = float(small[:, :, 0][mask].mean()) / max(float(small[:, :, 1][mask].mean()), 1e-6)
    if sat < t["saturation_fail"]:
        checks.append(QualityCheck("Colour balance", "fail", sat, "Image looks greyscale; a colour fundus photograph is required."))
    elif ratio < t["red_green_warn"]:
        checks.append(QualityCheck("Colour balance", "warn", ratio, "Colours are unlike a typical colour fundus photograph."))
    else:
        checks.append(QualityCheck("Colour balance", "ok", ratio, "Colour looks fundus-like."))

    if any(c.severity == "fail" for c in checks):
        return QualityReport("fail", checks, "Image is unsuitable for automated analysis. Retake or supply a better photograph.")
    if any(c.severity == "warn" for c in checks):
        return QualityReport("warn", checks, "Image quality is questionable; treat any result with extra caution.")
    return QualityReport("pass", checks, "No problems found by the heuristic checks (this does not guarantee the image is gradable).")
