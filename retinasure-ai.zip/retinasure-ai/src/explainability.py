"""Grad-CAM computed from the real loaded model on the real image.

Grad-CAM (Selvaraju et al., 2017) weights the last convolutional feature maps by the spatial mean of the
gradient of the class score, sums them, applies a ReLU and upsamples. It shows which regions influenced
the model's score for a class. It is NOT a lesion detector and NOT proof of disease.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

import cv2
import numpy as np

from .model_loader import LoadedModel, gradcam_target_layer
from .preprocessing import to_tensor

logger = logging.getLogger("retinasure")

HEATMAP_LEGEND = (
    "Warm colours (red/yellow) mark image regions that influenced the model's score most; cool colours (blue) "
    "influenced it least. This shows where the model looked. It is not a lesion map and not proof of disease, "
    "and it can highlight irrelevant areas."
)


@dataclass
class ExplainResult:
    available: bool
    message: str = ""
    target_class: Optional[int] = None
    heatmap: Optional[np.ndarray] = None   # float32 HxW in [0, 1]
    overlay: Optional[np.ndarray] = None   # uint8 HxWx3 RGB


def legend_bar(width: int = 400, height: int = 16) -> np.ndarray:
    """Colour legend image (blue = low influence ... red = high), uint8 HxWx3 RGB."""
    ramp = np.tile(np.linspace(0, 255, width, dtype=np.uint8), (height, 1))
    return cv2.cvtColor(cv2.applyColorMap(ramp, cv2.COLORMAP_JET), cv2.COLOR_BGR2RGB)


def compute_gradcam(m: LoadedModel, processed_rgb: np.ndarray, target_class: Optional[int] = None,
                    alpha: float = 0.45) -> ExplainResult:
    """Grad-CAM for one preprocessed (square uint8) image. Never raises; failures become messages."""
    if m is None or not m.usable:
        return ExplainResult(False, "No usable trained model, so no explanation can be computed.")
    import torch

    handle = None
    try:
        layer = gradcam_target_layer(m.model, m.arch)
        store: dict = {}
        handle = layer.register_forward_hook(lambda _mod, _inp, out: store.__setitem__("act", out))
        with torch.enable_grad():
            logits = m.model(to_tensor(processed_rgb))
            cls = int(logits.argmax(1).item()) if target_class is None else int(target_class)
            act = store["act"]
            # autograd.grad (not backward) so no gradients are left on the model's parameters
            grad = torch.autograd.grad(logits[0, cls], act)[0]
        weights = grad.detach()[0].mean(dim=(1, 2))
        cam = torch.relu((weights[:, None, None] * act.detach()[0]).sum(0)).cpu().numpy()
        if not np.isfinite(cam).all():
            return ExplainResult(False, "Grad-CAM could not be computed: non-finite values in the model gradients.",
                                 target_class=cls)
        h, w = processed_rgb.shape[:2]
        empty = cam.max() <= 1e-12   # ReLU removed everything: no region positively supported this class
        cam = np.zeros((h, w), np.float32) if empty else np.clip(
            cv2.resize((cam / cam.max()).astype(np.float32), (w, h), interpolation=cv2.INTER_CUBIC), 0.0, 1.0)
        disc = np.zeros((h, w), np.float32)
        cv2.circle(disc, (w // 2, h // 2), int(min(h, w) * 0.5), 1.0, -1)   # ignore the black corners
        cam = cam * disc
        colour = cv2.cvtColor(cv2.applyColorMap((cam * 255).astype(np.uint8), cv2.COLORMAP_JET), cv2.COLOR_BGR2RGB)
        overlay = cv2.addWeighted(processed_rgb, 1 - alpha, colour, alpha, 0)
        note = ("No image region positively supported this class (the Grad-CAM map is empty), so no highlight is drawn."
                if empty else "")
        return ExplainResult(True, note, cls, cam.astype(np.float32), overlay)
    except Exception as exc:
        logger.warning("Grad-CAM failed: %s", type(exc).__name__)
        return ExplainResult(False, f"Grad-CAM could not be computed ({type(exc).__name__}). The result above is unaffected.")
    finally:
        if handle is not None:
            handle.remove()
