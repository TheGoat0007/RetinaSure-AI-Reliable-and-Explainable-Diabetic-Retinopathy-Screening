"""Central configuration for RetinaSure AI.

Every threshold here is a provisional default that has NOT been validated on clinical data.
Modules read these values at call time (``config.X``) so tests and users can override them.
"""
from __future__ import annotations

import os
from pathlib import Path

APP_NAME = "RetinaSure AI"
APP_VERSION = "0.1.0"
PROBLEM_STATEMENT = "PS-068: AI-Powered Diabetic Retinopathy Detection and Explainable Screening System"

PROJECT_ROOT = Path(__file__).resolve().parent.parent
MODELS_DIR = PROJECT_ROOT / "models"

# Where the app looks for a trained checkpoint / evaluation file. Override with environment variables.
DEFAULT_MODEL_PATH = Path(os.environ.get("RETINASURE_MODEL_PATH", MODELS_DIR / "retinasure_dr.pt"))
# The evaluation file and training history are read from the same folder as the checkpoint.

# International clinical DR severity scale (as used by APTOS 2019).
CLASS_NAMES = ["No DR", "Mild NPDR", "Moderate NPDR", "Severe NPDR", "Proliferative DR"]
NUM_CLASSES = len(CLASS_NAMES)
REFERABLE_THRESHOLD = 2  # grade >= 2 (moderate or worse) is the usual "referable DR" cut-off

# Upload limits.
SUPPORTED_EXTENSIONS = (".jpg", ".jpeg", ".png")
MAX_FILE_MB = 10.0
MAX_UPLOAD_BYTES = int(MAX_FILE_MB * 1024 * 1024)
MAX_IMAGE_PIXELS = 40_000_000     # decompression-bomb guard (about 6300 x 6300)
MAX_BATCH_FILES = 20

# Model.
SUPPORTED_ARCHS = ("resnet18", "resnet50", "efficientnet_b0")
DEFAULT_ARCH = "efficientnet_b0"
DEFAULT_IMG_SIZE = 320
MAX_CHECKPOINT_MB = 500

SHORT_DISCLAIMER = (
    "RetinaSure AI is an educational and research prototype. It is not a medical device and its output is "
    "not a medical diagnosis. It cannot replace an eye-care professional."
)

DISCLAIMER_POINTS = [
    "This is an educational and research prototype built for a student innovation challenge.",
    "Its output is not a confirmed medical diagnosis.",
    "A normal-looking (No DR) result does not rule out diabetic retinopathy; the model can miss disease.",
    "Everyone with diabetes should follow professional diabetic eye-screening guidance regardless of this tool.",
    "For sudden vision loss, a curtain or shadow over your vision, or a shower of new floaters, seek urgent medical care.",
]

# Placeholders on purpose: edit these yourself. Nothing here is invented.
PROJECT_CONTACT = {
    "Student / team name": "[Your name here]",
    "School": "[Your school here]",
    "Contact email": "[Your email here]",
    "Code repository": "[Your GitHub repository URL here]",
}
