"""Upload validation, safe decoding and privacy helpers.

Privacy behaviour of this module and of the app that uses it:
* Uploads are handled as bytes in memory. Nothing is written to disk.
* Only the pixel array is kept; EXIF and other metadata are dropped.
* Reports use an anonymous reference derived from the file bytes, never the filename (unless the user opts in).
* Image contents are never logged.

Not controlled here: Streamlit keeps uploaded files in server memory during a session, and a hosting
provider may keep its own logs. See README -> Privacy.
"""
from __future__ import annotations

import hashlib
import io
import logging
import re
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps, UnidentifiedImageError

from . import config

logger = logging.getLogger("retinasure")

_JPEG = b"\xff\xd8\xff"
_PNG = b"\x89PNG\r\n\x1a\n"


class UploadError(ValueError):
    """Any problem with an uploaded file. The message is safe to show to the user."""


def validate_upload(filename: str | None, data: bytes) -> np.ndarray:
    """Validate and decode an upload into an RGB uint8 array. Raises UploadError."""
    if not data:
        raise UploadError("The file is empty.")
    if len(data) > config.MAX_UPLOAD_BYTES:
        raise UploadError(f"The file is too large (limit {config.MAX_UPLOAD_BYTES / 1024 / 1024:g} MB).")
    ext = Path(filename or "").suffix.lower()
    if ext not in config.SUPPORTED_EXTENSIONS:
        allowed = ", ".join(e.lstrip(".").upper() for e in config.SUPPORTED_EXTENSIONS)
        raise UploadError(f"Unsupported file type '{ext or 'none'}'. Please upload one of: {allowed}.")
    if data.startswith(_JPEG):
        kind = "jpeg"
    elif data.startswith(_PNG):
        kind = "png"
    else:
        raise UploadError("The file content is not a PNG or JPEG image (it may be corrupted or renamed).")
    if (kind == "jpeg") != (ext in (".jpg", ".jpeg")):
        raise UploadError("The file extension does not match the file content.")
    try:
        with Image.open(io.BytesIO(data)) as img:
            w, h = img.size
            if w * h > config.MAX_IMAGE_PIXELS:
                raise UploadError(f"The image is too large to process safely ({w}x{h} pixels).")
            img.load()  # full decode: catches truncated / corrupted data
            img = ImageOps.exif_transpose(img)
            return np.asarray(img.convert("RGB"), dtype=np.uint8).copy()
    except UploadError:
        raise
    except (UnidentifiedImageError, OSError, SyntaxError, ValueError, EOFError, Image.DecompressionBombError) as exc:
        logger.warning("Image decode failed: %s", type(exc).__name__)
        raise UploadError("The image could not be decoded. It may be corrupted or incomplete.") from exc


def anonymous_id(data: bytes) -> str:
    """Reference such as 'RS-3F9A1C07B2' that depends only on the bytes, not on any filename."""
    return "RS-" + hashlib.sha256(data).hexdigest()[:10].upper()


def safe_filename(name: str | None) -> str:
    """Strip directories and control characters from a filename."""
    cleaned = re.sub(r"[\x00-\x1f\x7f]", "", name or "")
    base = re.split(r"[\\/]", cleaned)[-1].strip()
    return base or "unnamed"
