"""Safe screening logic: when to report a category and when to abstain.

Softmax confidence is NOT a calibrated clinical probability. The default thresholds are provisional.
Choose them on a *validation* split using the risk-coverage table written by
`training/evaluate.py --role val`, and check calibration (ECE) before claiming anything about
probabilities. See docs/SAFETY_AND_LIMITATIONS.md.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional, Sequence

from . import config

# Decision statuses
NO_MODEL = "no_model"
UNGRADABLE = "ungradable"
ABSTAIN = "abstain"
REPORTED = "reported"

SCREENING_REMINDER = "Please keep to your professional eye-screening schedule."

_NEXT_STEP = {
    0: "The model did not flag diabetic retinopathy, but this does not rule out disease.",
    1: "The model suggests possible early changes. Arrange an eye examination with an eye-care professional.",
    2: "The model suggests possible moderate changes (referable level). Arrange an eye-care review soon.",
    3: "The model suggests possible severe changes. Seek prompt professional eye evaluation; do not wait for a routine visit.",
    4: "The model suggests possible advanced changes. Seek prompt, preferably urgent, professional eye evaluation.",
}


@dataclass(frozen=True)
class UncertaintyConfig:
    min_confidence: float = 0.60        # top-class softmax probability
    min_margin: float = 0.15            # top-1 minus top-2 probability
    max_normalized_entropy: float = 0.85  # 0 = certain, 1 = uniform


@dataclass
class Decision:
    status: str
    title: str
    message: str
    next_step: str
    has_prediction: bool = False
    predicted_class: Optional[int] = None
    predicted_label: Optional[str] = None
    confidence: Optional[float] = None
    reasons: list[str] = field(default_factory=list)
    caution: bool = False


def _normalise(probs: Sequence[float]) -> list[float]:
    p = [max(0.0, float(x)) for x in probs]
    total = sum(p)
    return [x / total for x in p] if total > 0 else [0.0] * len(p)


def normalized_entropy(probs: Sequence[float]) -> float:
    p = _normalise(probs)
    if len(p) < 2:
        return 0.0
    h = -sum(x * math.log(x) for x in p if x > 0)
    return h / math.log(len(p)) + 0.0


def decide(model_status: str, quality_status: str, probs: Optional[Sequence[float]],
           cfg: UncertaintyConfig = UncertaintyConfig()) -> Decision:
    """Combine model availability, image quality and uncertainty into one safe decision."""
    if model_status != "configured":
        titles = {"unconfigured": "Model not configured: demo mode, no clinical prediction available",
                  "demo_only": "Demo mode: this checkpoint is a pipeline test and cannot be used for predictions",
                  "error": "Model could not be used: no prediction available"}
        return Decision(NO_MODEL, titles.get(model_status, "No model output available"),
                        "No trained model is available, so no severity category is provided. Image upload and quality checks "
                        "are real; nothing here is a diagnosis.",
                        "Follow professional eye-screening guidance and have your eyes examined by an eye-care professional.")
    if quality_status == "fail":
        return Decision(UNGRADABLE, "Image not suitable for analysis",
                        "The heuristic quality checks failed, so the model was not run and no category is provided.",
                        "Retake the photograph (or re-export the original file without compression) and try again. If a good "
                        "image cannot be obtained, ask an eye-care professional to examine you.")
    if probs is None or len(probs) != config.NUM_CLASSES:
        return Decision(NO_MODEL, "No model output available", "The model did not return a usable output, so no severity "
                        "category is provided.", "Try again, and follow professional eye-screening guidance.")

    p = _normalise(probs)
    order = sorted(range(len(p)), key=lambda i: p[i], reverse=True)
    top, second = p[order[0]], p[order[1]]
    ent = normalized_entropy(p)
    reasons = []
    if top < cfg.min_confidence:
        reasons.append(f"top-class score {top:.0%} is below the {cfg.min_confidence:.0%} threshold")
    if top - second < cfg.min_margin:
        reasons.append(f"gap between the top two classes ({top - second:.0%}) is below {cfg.min_margin:.0%}")
    if ent > cfg.max_normalized_entropy:
        reasons.append(f"entropy {ent:.2f} is above the {cfg.max_normalized_entropy:.2f} limit (scores are spread out)")
    if reasons:
        return Decision(ABSTAIN, "Result withheld: the model is not confident enough",
                        "The model abstains rather than risk an unreliable category: " + "; ".join(reasons) + ".",
                        "No category is shown because it could be wrong. Please have the image reviewed by a qualified "
                        "professional. " + SCREENING_REMINDER, reasons=reasons)

    cls = order[0]
    caution = quality_status == "warn"
    return Decision(REPORTED, f"Model output: {config.CLASS_NAMES[cls]}",
                    "A model score, not a diagnosis. " + ("Image quality was flagged as questionable, so treat it with extra caution."
                                                          if caution else ""),
                    _NEXT_STEP[cls] + " " + SCREENING_REMINDER,
                    has_prediction=True, predicted_class=cls, predicted_label=config.CLASS_NAMES[cls], confidence=top,
                    reasons=["image_quality_warning"] if caution else [], caution=caution)
