# assets/

Optional place for your own logo, screenshots for the presentation, and diagrams.

- Do **not** put real patient images or images from restricted datasets here.
- Screenshots of the running app (taken by you) are fine for your presentation.
