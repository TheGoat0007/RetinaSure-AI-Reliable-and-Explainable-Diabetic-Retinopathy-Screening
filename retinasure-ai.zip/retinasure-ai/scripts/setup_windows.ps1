# One-time setup on Windows. Run from the project folder:
#   powershell -ExecutionPolicy Bypass -File .\scripts\setup_windows.ps1
$ErrorActionPreference = "Stop"
python --version
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
Write-Host "`nRunning the automated tests..."
.\.venv\Scripts\python.exe -m pytest
Write-Host "`nSetup finished. Start the app with:  powershell -ExecutionPolicy Bypass -File .\scripts\run_app.ps1"
