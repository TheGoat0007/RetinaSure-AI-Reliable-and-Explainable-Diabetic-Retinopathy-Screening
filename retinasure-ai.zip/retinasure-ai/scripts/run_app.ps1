# Start RetinaSure AI. Run from the project folder.
.\.venv\Scripts\python.exe -m streamlit run app.py
