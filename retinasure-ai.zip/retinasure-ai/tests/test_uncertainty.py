import math

import pytest

from src import uncertainty as u

CFG = u.UncertaintyConfig(min_confidence=0.6, min_margin=0.15, max_normalized_entropy=0.8)
CONFIDENT = [0.05, 0.85, 0.05, 0.03, 0.02]
FLAT = [0.2, 0.2, 0.2, 0.2, 0.2]


def test_entropy_bounds():
    assert u.normalized_entropy([1, 0, 0, 0, 0]) == 0
    assert math.isclose(u.normalized_entropy(FLAT), 1.0)


@pytest.mark.parametrize("model_status", ["unconfigured", "demo_only", "error"])
def test_model_unavailable_has_no_category(model_status):
    d = u.decide(model_status, "pass", CONFIDENT, CFG)
    assert d.status == u.NO_MODEL and not d.has_prediction and d.predicted_label is None
    assert d.confidence is None


def test_model_unavailable_takes_precedence_over_everything():
    assert u.decide("unconfigured", "fail", None, CFG).status == u.NO_MODEL


def test_failed_quality_is_ungradable_even_if_model_is_confident():
    d = u.decide("configured", "fail", CONFIDENT, CFG)
    assert d.status == u.UNGRADABLE and not d.has_prediction
    assert "retake" in d.next_step.lower() or "re-export" in d.next_step.lower()


def test_confident_prediction_is_reported():
    d = u.decide("configured", "pass", CONFIDENT, CFG)
    assert d.status == u.REPORTED and d.predicted_class == 1 and d.predicted_label == "Mild NPDR"
    assert d.confidence == pytest.approx(0.85) and not d.caution


def test_quality_warning_adds_caution():
    d = u.decide("configured", "warn", CONFIDENT, CFG)
    assert d.status == u.REPORTED and d.caution and "image_quality_warning" in d.reasons


@pytest.mark.parametrize("probs,reason", [
    ([0.4, 0.3, 0.1, 0.1, 0.1], "below"),
    ([0.55, 0.50, 0.0, 0.0, -0.05 + 0.05], "gap"),
    (FLAT, "entropy"),
])
def test_low_confidence_abstains(probs, reason):
    d = u.decide("configured", "pass", probs, CFG)
    assert d.status == u.ABSTAIN and d.predicted_class is None and d.predicted_label is None
    assert any(reason in r for r in d.reasons)
    assert "professional" in d.next_step.lower()


def test_thresholds_are_configurable():
    probs = [0.5, 0.2, 0.1, 0.1, 0.1]
    assert u.decide("configured", "pass", probs, CFG).status == u.ABSTAIN
    loose = u.UncertaintyConfig(0.4, 0.1, 1.0)
    assert u.decide("configured", "pass", probs, loose).status == u.REPORTED


def test_missing_probabilities_do_not_produce_a_result():
    d = u.decide("configured", "pass", None, CFG)
    assert not d.has_prediction


@pytest.mark.parametrize("cls", range(5))
def test_every_outcome_recommends_continued_professional_screening(cls):
    probs = [0.02] * 5
    probs[cls] = 0.92
    d = u.decide("configured", "pass", probs, CFG)
    assert "screening schedule" in d.next_step
    if cls == 0:
        assert "does not rule out" in d.next_step.lower()  # no false reassurance
