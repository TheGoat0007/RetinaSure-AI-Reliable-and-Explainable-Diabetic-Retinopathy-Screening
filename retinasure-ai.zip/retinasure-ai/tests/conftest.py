"""Shared test helpers.

IMPORTANT: ``make_fundus_like`` draws a SYNTHETIC picture that merely has the
broad statistics of a fundus photo (dark border, reddish disc, vessel-like
lines, fine texture). It is NOT a retinal image and any model output on it is
meaningless. It exists so that plumbing can be tested without real patient data.
"""
from __future__ import annotations

import io
import sys
from pathlib import Path

import cv2
import numpy as np
import pytest
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def make_fundus_like(size: int = 640, seed: int = 0) -> np.ndarray:
    rng = np.random.default_rng(seed)
    img = np.zeros((size, size, 3), np.uint8)
    c, r = size // 2, int(size * 0.46)
    yy, xx = np.mgrid[:size, :size]
    dist = np.sqrt((yy - c) ** 2 + (xx - c) ** 2) / r
    disc = dist <= 1.0
    base = np.stack([200 - 60 * dist, 95 - 30 * dist, 40 - 10 * dist], axis=-1)
    img[disc] = np.clip(base[disc], 0, 255).astype(np.uint8)
    for _ in range(25):  # vessel-like dark curves
        x0, y0 = rng.integers(c - r // 2, c + r // 2, 2)
        pts = [(x0, y0)]
        for _ in range(8):
            x0 = int(np.clip(pts[-1][0] + rng.integers(-60, 60), 0, size - 1))
            y0 = int(np.clip(pts[-1][1] + rng.integers(-60, 60), 0, size - 1))
            pts.append((x0, y0))
        cv2.polylines(img, [np.array(pts, np.int32)], False, (110, 25, 15), 2, cv2.LINE_AA)
    cv2.circle(img, (c + r // 3, c), r // 9, (235, 200, 120), -1)  # bright blob (disc-like)
    noise = rng.normal(0, 6, img.shape)
    img = np.clip(img + noise * disc[:, :, None], 0, 255).astype(np.uint8)
    img[~disc] = 0
    return img


def encode(rgb: np.ndarray, fmt: str = "PNG", quality: int = 92) -> bytes:
    buf = io.BytesIO()
    kwargs = {"quality": quality} if fmt.upper() == "JPEG" else {}
    Image.fromarray(rgb).save(buf, format=fmt, **kwargs)
    return buf.getvalue()


@pytest.fixture(scope="session")
def fundus() -> np.ndarray:
    return make_fundus_like()


@pytest.fixture(scope="session")
def tiny_checkpoint(tmp_path_factory) -> Path:
    """A randomly initialised resnet18 checkpoint, for plumbing tests ONLY."""
    torch = pytest.importorskip("torch")
    from src.model_loader import build_model

    path = tmp_path_factory.mktemp("ckpt") / "plumbing_only.pt"
    torch.manual_seed(0)
    net = build_model("resnet18", 5, pretrained=False)
    torch.save({
        "state_dict": net.state_dict(), "arch": "resnet18", "num_classes": 5, "img_size": 64,
        "class_names": ["No DR", "Mild NPDR", "Moderate NPDR", "Severe NPDR", "Proliferative DR"],
        "preprocess": "crop_resize", "version": "test-0", "dataset_name": "NONE (random weights)",
    }, path)
    return path
