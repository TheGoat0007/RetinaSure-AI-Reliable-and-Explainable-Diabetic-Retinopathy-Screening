"""Pipeline tests on a tiny SYNTHETIC dataset.

These verify that the training and evaluation code runs end to end and that
the metric maths is right. They say NOTHING about real diagnostic performance.
"""
import json

import cv2
import numpy as np
import pandas as pd
import pytest

from tests.conftest import make_fundus_like

torch = pytest.importorskip("torch")
from training import dataset as ds  # noqa: E402
from training import evaluate as ev  # noqa: E402
from training import train as tr  # noqa: E402


@pytest.fixture(scope="module")
def synthetic_data(tmp_path_factory):
    root = tmp_path_factory.mktemp("synth")
    (root / "images").mkdir()
    rng = np.random.default_rng(0)
    rows = []
    for i in range(60):
        label = i % 5
        img = make_fundus_like(160, seed=i)
        cv2.imwrite(str(root / "images" / f"img{i}.png"), cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
        rows.append({"id_code": f"img{i}", "diagnosis": label, "pid": f"p{i // 2}"})
    pd.DataFrame(rows).to_csv(root / "labels.csv", index=False)
    return root


# ------------------------------ dataset ------------------------------------- #
def test_load_table_validates_and_resolves_paths(synthetic_data):
    t = ds.load_table(synthetic_data / "labels.csv", synthetic_data / "images")
    assert len(t) == 60 and (t["path"] != "").all()


def test_out_of_range_labels_rejected(tmp_path):
    pd.DataFrame({"id_code": ["a"], "diagnosis": [7]}).to_csv(tmp_path / "l.csv", index=False)
    with pytest.raises(ValueError, match="outside"):
        ds.load_table(tmp_path / "l.csv", tmp_path)


def test_missing_images_are_dropped_with_warning(synthetic_data, tmp_path, capsys):
    df = pd.read_csv(synthetic_data / "labels.csv")
    df.loc[len(df)] = {"id_code": "ghost", "diagnosis": 0, "pid": "pz"}
    df.to_csv(tmp_path / "l.csv", index=False)
    t = ds.load_table(tmp_path / "l.csv", synthetic_data / "images")
    assert len(t) == 60 and "not found" in capsys.readouterr().out


def test_patient_level_split_has_no_patient_overlap(synthetic_data):
    t = ds.load_table(synthetic_data / "labels.csv", synthetic_data / "images", patient_col="pid")
    s = ds.split_table(t, 0.2, 0.2, seed=1)
    pats = {k: set(v["patient_id"]) for k, v in s.items()}
    assert not (pats["train"] & pats["val"]) and not (pats["train"] & pats["test"]) and not (pats["val"] & pats["test"])
    assert sum(len(v) for v in s.values()) == 60


def test_split_is_reproducible(synthetic_data):
    t = ds.load_table(synthetic_data / "labels.csv", synthetic_data / "images")
    a, b = ds.split_table(t, seed=3), ds.split_table(t, seed=3)
    assert list(a["test"]["image_id"]) == list(b["test"]["image_id"])


def test_class_weights_inverse_frequency():
    w = ds.class_weights(np.array([0] * 90 + [1] * 10), 5)
    assert w[1] > w[0] and w[2] == 0


# ------------------------------ metrics ------------------------------------- #
def one_hot(y):
    p = np.full((len(y), 5), 0.0)
    p[np.arange(len(y)), y] = 1.0
    return p


def test_perfect_predictions():
    y = np.array([0, 1, 2, 3, 4, 0, 2, 4])
    m = ev.compute_metrics(y, one_hot(y))
    assert m["accuracy"] == 1 and m["quadratic_weighted_kappa"] == pytest.approx(1)
    assert m["referable_dr"]["sensitivity"] == 1 and m["referable_dr"]["specificity"] == 1
    assert m["roc_auc_ovr_macro"] == pytest.approx(1)
    assert np.trace(np.array(m["confusion_matrix"])) == len(y)


def test_known_confusion_and_binary_endpoints():
    y_true = np.array([0, 0, 0, 0, 2, 2, 3, 4])
    y_pred = np.array([0, 0, 1, 0, 2, 1, 3, 0])   # one mild FP, two missed referable (class 2->1, 4->0)
    m = ev.compute_metrics(y_true, one_hot(y_pred))
    assert m["accuracy"] == pytest.approx(5 / 8)
    r = m["referable_dr"]
    assert (r["tp"], r["fn"], r["tn"], r["fp"]) == (2, 2, 4, 0)
    assert r["sensitivity"] == pytest.approx(0.5) and r["specificity"] == 1
    a = m["any_dr"]
    assert (a["tp"], a["fn"], a["tn"], a["fp"]) == (3, 1, 3, 1)


def test_undefined_metrics_are_none_not_fabricated():
    y = np.array([0, 0, 0, 0])
    m = ev.compute_metrics(y, one_hot(y))
    assert m["roc_auc_ovr"]["Mild NPDR"] is None and m["referable_dr"]["sensitivity"] is None
    assert m["class_distribution"]["No DR"] == 4


def test_ece_zero_when_confidence_matches_accuracy():
    conf = np.array([1.0] * 10)
    assert ev.expected_calibration_error(conf, np.ones(10, bool)) == 0
    assert ev.expected_calibration_error(conf, np.zeros(10, bool)) == pytest.approx(1)


def test_wilson_interval_contains_estimate():
    lo, hi = ev.wilson_interval(8, 10)
    assert lo < 0.8 < hi and ev.wilson_interval(0, 0) is None


def test_risk_coverage_monotone():
    rng = np.random.default_rng(0)
    probs = rng.dirichlet(np.ones(5), 200)
    y = rng.integers(0, 5, 200)
    cov = [r["coverage"] for r in ev.compute_metrics(y, probs)["risk_coverage"]["by_min_confidence"]]
    assert cov == sorted(cov, reverse=True)


def test_bad_probability_shape_rejected():
    with pytest.raises(ValueError):
        ev.compute_metrics([0, 1], np.ones((2, 3)))


# ------------------------------ end to end ---------------------------------- #
def test_train_then_evaluate_smoke(synthetic_data, tmp_path):
    out = tmp_path / "m" / "smoke.pt"
    splits = tmp_path / "splits"
    tr.main(["--csv", str(synthetic_data / "labels.csv"), "--image-dir", str(synthetic_data / "images"),
             "--dataset-name", "SYNTHETIC", "--arch", "resnet18", "--img-size", "64", "--epochs", "1",
             "--batch-size", "8", "--output", str(out), "--splits-dir", str(splits), "--smoke-test",
             "--patient-col", "pid"])
    assert out.is_file() and out.with_suffix(".history.json").is_file() and out.with_suffix(".loss.png").is_file()
    ckpt = torch.load(out, weights_only=True)
    assert ckpt["smoke_test"] is True and ckpt["dataset_name"] == "SYNTHETIC" and ckpt["patient_level_split"]

    # the app must refuse to use it
    from src.model_loader import load_model
    assert load_model(out).status == "demo_only"

    m = ev.main(["--checkpoint", str(out), "--csv", str(splits / "test.csv")])
    saved = json.loads((out.parent / "evaluation_metrics.json").read_text())
    assert saved["provenance"]["smoke_test"] is True and saved["n_samples"] == m["n_samples"] > 0
    assert (out.parent / "evaluation_metrics.confusion.png").is_file()


def test_evaluate_aborts_on_leakage(tmp_path):
    pd.DataFrame({"image_id": ["a", "b"], "label": [0, 1]}).to_csv(tmp_path / "train.csv", index=False)
    pd.DataFrame({"image_id": ["b", "c"], "label": [1, 0]}).to_csv(tmp_path / "test.csv", index=False)
    with pytest.raises(SystemExit, match="LEAKAGE"):
        ev.check_no_leakage(tmp_path / "test.csv")


def test_training_is_reproducible(synthetic_data, tmp_path):
    outs = []
    for i in range(2):
        out = tmp_path / f"r{i}.pt"
        tr.main(["--csv", str(synthetic_data / "labels.csv"), "--image-dir", str(synthetic_data / "images"),
                 "--dataset-name", "SYNTHETIC", "--arch", "resnet18", "--img-size", "48", "--epochs", "1",
                 "--batch-size", "8", "--output", str(out), "--splits-dir", str(tmp_path / f"s{i}"),
                 "--smoke-test", "--seed", "7"])
        outs.append(torch.load(out, weights_only=True)["state_dict"])
    for k in outs[0]:
        assert torch.allclose(outs[0][k].float(), outs[1][k].float(), atol=1e-5), k
