import io
import os

import numpy as np
import pytest
from PIL import Image

from src import config, privacy
from src.privacy import UploadError, validate_upload
from tests.conftest import encode


def test_valid_png_and_jpeg_accepted(fundus):
    for fmt, name in (("PNG", "a.png"), ("JPEG", "a.jpg"), ("JPEG", "A.JPEG")):
        out = validate_upload(name, encode(fundus, fmt))
        assert out.shape == fundus.shape and out.dtype == np.uint8


@pytest.mark.parametrize("name", ["scan.gif", "scan.exe", "scan", "scan.pdf", "scan.tiff"])
def test_unsupported_extensions_rejected(name, fundus):
    with pytest.raises(UploadError, match="Unsupported"):
        validate_upload(name, encode(fundus))


def test_empty_file_rejected():
    with pytest.raises(UploadError, match="empty"):
        validate_upload("a.png", b"")


def test_oversize_file_rejected(monkeypatch, fundus):
    monkeypatch.setattr(config, "MAX_UPLOAD_BYTES", 1000)
    with pytest.raises(UploadError, match="too large"):
        validate_upload("a.png", encode(fundus))


def test_executable_renamed_to_png_rejected():
    with pytest.raises(UploadError, match="not a PNG or JPEG"):
        validate_upload("evil.png", b"MZ\x90\x00" + b"\x00" * 200)


def test_extension_content_mismatch_rejected(fundus):
    with pytest.raises(UploadError, match="does not match"):
        validate_upload("a.png", encode(fundus, "JPEG"))


def test_truncated_image_rejected(fundus):
    data = encode(fundus, "PNG")
    with pytest.raises(UploadError, match="could not be decoded"):
        validate_upload("a.png", data[: len(data) // 3])


def test_corrupted_bytes_after_header_rejected():
    with pytest.raises(UploadError):
        validate_upload("a.png", b"\x89PNG\r\n\x1a\n" + os.urandom(300))


def test_pixel_limit_blocks_huge_dimensions(monkeypatch):
    monkeypatch.setattr(config, "MAX_IMAGE_PIXELS", 1000)
    buf = io.BytesIO()
    Image.new("RGB", (100, 100)).save(buf, "PNG")
    with pytest.raises(UploadError, match="too large to process"):
        validate_upload("a.png", buf.getvalue())


def test_metadata_is_dropped(fundus):
    buf = io.BytesIO()
    exif = Image.Exif()
    exif[0x010E] = "Patient: Jane Doe"
    Image.fromarray(fundus).save(buf, "JPEG", exif=exif)
    out = validate_upload("a.jpg", buf.getvalue())
    assert isinstance(out, np.ndarray)  # only pixels are returned; no EXIF carrier


def test_anonymous_id_depends_only_on_bytes():
    a = privacy.anonymous_id(b"abc")
    assert a == privacy.anonymous_id(b"abc") and a != privacy.anonymous_id(b"abd")
    assert a.startswith("RS-") and len(a) == 13


def test_safe_filename_strips_paths_and_control_chars():
    assert privacy.safe_filename("C:\\Users\\Jane\\eye.png") == "eye.png"
    assert privacy.safe_filename("../../etc/passwd\x00.png") == "passwd.png"
    assert privacy.safe_filename("") == "unnamed"


def test_full_pipeline_writes_no_files(tmp_path, monkeypatch, fundus):
    """Validation, screening (no model) and reports must not touch the disk."""
    from src import inference, model_loader, report_generator as rg
    monkeypatch.chdir(tmp_path)
    data = encode(fundus)
    rgb = validate_upload("a.png", data)
    res = inference.run_screening(rgb, model_loader.load_model(tmp_path / "none.pt"),
                                  anon_id=privacy.anonymous_id(data))
    rg.generate_html(res); rg.generate_pdf(res); rg.generate_csv([res])
    assert list(tmp_path.iterdir()) == []
