import cv2
import numpy as np

from src.image_quality import assess_quality
from tests.conftest import make_fundus_like


def sev(report, name):
    return next(c.severity for c in report.checks if c.name.startswith(name))


def test_synthetic_good_image_passes(fundus):
    r = assess_quality(fundus)
    assert r.status == "pass" and r.suitable
    assert all(c.passed for c in r.checks)


def test_too_small_fails(fundus):
    r = assess_quality(cv2.resize(fundus, (200, 200)))
    assert r.status == "fail" and sev(r, "Resolution") == "fail"


def test_low_resolution_warns(fundus):
    r = assess_quality(cv2.resize(fundus, (400, 400)))
    assert sev(r, "Resolution") == "warn" and r.status == "warn"


def test_dark_image_fails(fundus):
    r = assess_quality((fundus * 0.15).astype(np.uint8))
    assert r.status == "fail"


def test_overexposed_image_fails(fundus):
    r = assess_quality(np.clip(fundus.astype(np.float32) * 4.0, 0, 255).astype(np.uint8))
    assert r.status == "fail" and sev(r, "Brightness") == "fail"


def test_moderately_bright_image_only_warns(fundus):
    r = assess_quality(np.clip(fundus.astype(np.float32) * 3.2, 0, 255).astype(np.uint8))
    assert sev(r, "Brightness") == "warn" and r.status == "warn"


def test_blurred_image_is_not_a_pass(fundus):
    r = assess_quality(cv2.GaussianBlur(fundus, (0, 0), 20))
    assert sev(r, "Sharpness") in ("warn", "fail") and r.status != "pass"


def test_black_image_has_no_field_of_view():
    r = assess_quality(np.zeros((640, 640, 3), np.uint8))
    assert r.status == "fail" and sev(r, "Retinal") == "fail"


def test_flat_gray_image_fails():
    r = assess_quality(np.full((640, 640, 3), 128, np.uint8))
    assert r.status == "fail"


def test_non_reddish_image_is_flagged(fundus):
    r = assess_quality(fundus[:, :, ::-1].copy())  # swap R and B
    assert sev(r, "Colour") == "warn" and r.status != "pass"


def test_non_rgb_input_fails_gracefully():
    r = assess_quality(np.zeros((100, 100), np.uint8))
    assert r.status == "fail"


def test_report_exposes_rows_and_heuristic_note(fundus):
    r = assess_quality(fundus)
    assert len(r.as_rows()) == len(r.checks)
    assert "not a validated clinical" in r.note


def test_quality_is_resolution_independent_for_sharpness():
    a = assess_quality(make_fundus_like(640, seed=1))
    b = assess_quality(make_fundus_like(1024, seed=1))
    assert sev(a, "Sharpness") == sev(b, "Sharpness") == "ok"
