import numpy as np
import pytest

from src import preprocessing as pp


def test_crop_removes_black_border(fundus):
    padded = np.pad(fundus, ((50, 50), (80, 80), (0, 0)))
    cropped = pp.crop_to_fov(padded)
    assert cropped.shape[0] < padded.shape[0] and cropped.shape[1] < padded.shape[1]


def test_crop_keeps_all_black_image_unchanged():
    black = np.zeros((100, 100, 3), np.uint8)
    assert pp.crop_to_fov(black).shape == black.shape


@pytest.mark.parametrize("shape", [(300, 500), (640, 640), (1200, 800)])
def test_output_is_square_uint8(fundus, shape):
    import cv2
    img = cv2.resize(fundus, (shape[1], shape[0]))
    out = pp.preprocess_image(img, 128)
    assert out.shape == (128, 128, 3) and out.dtype == np.uint8


def test_ben_graham_method_runs(fundus):
    out = pp.preprocess_image(fundus, 128, "ben_graham")
    assert out.shape == (128, 128, 3) and out.dtype == np.uint8


def test_unknown_method_raises(fundus):
    with pytest.raises(ValueError):
        pp.preprocess_image(fundus, 64, "magic")


def test_grayscale_input_raises():
    with pytest.raises(ValueError):
        pp.preprocess_image(np.zeros((50, 50), np.uint8), 64)


def test_preprocessing_is_deterministic(fundus):
    assert np.array_equal(pp.preprocess_image(fundus, 96), pp.preprocess_image(fundus, 96))


def test_to_tensor_shape_and_normalisation(fundus):
    torch = pytest.importorskip("torch")
    t = pp.to_tensor(pp.preprocess_image(fundus, 64))
    assert tuple(t.shape) == (1, 3, 64, 64) and t.dtype == torch.float32
    assert torch.isfinite(t).all()
    white = pp.to_tensor(np.full((8, 8, 3), 255, np.uint8))
    assert abs(white[0, 0, 0, 0].item() - (1 - 0.485) / 0.229) < 1e-4
