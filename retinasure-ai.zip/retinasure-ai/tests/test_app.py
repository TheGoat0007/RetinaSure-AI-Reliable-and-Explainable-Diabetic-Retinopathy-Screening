"""Headless UI tests using Streamlit's AppTest (no browser needed).

Limitations: AppTest cannot drive the file-upload widget, so upload handling is
covered through src/privacy.py tests and by seeding session state with a real
ScreeningResult for the Results page. Visual layout is NOT checked here.
"""
import pytest

pytest.importorskip("torch")
from streamlit.testing.v1 import AppTest  # noqa: E402

from src import config, inference, model_loader, privacy, uncertainty  # noqa: E402

APP = str(config.PROJECT_ROOT / "app.py")


def run(page: str, monkeypatch, tmp_path, model_path=None, state=None) -> AppTest:
    monkeypatch.setattr(config, "DEFAULT_MODEL_PATH", model_path or (tmp_path / "missing.pt"))
    at = AppTest.from_file(APP, default_timeout=60)
    at.session_state["page"] = page
    for k, v in (state or {}).items():
        at.session_state[k] = v
    return at.run()


def text_of(at: AppTest) -> str:
    parts = [e.value for e in at.markdown] + [e.value for e in at.info] + [e.value for e in at.warning]
    parts += [e.value for e in at.title] + [e.value for e in at.subheader] + [e.value for e in at.caption]
    return "\n".join(map(str, parts))


@pytest.mark.parametrize("page", ["Home", "Image Screening", "Results", "Model & Evaluation", "About & Safety"])
def test_every_page_renders_without_model(page, monkeypatch, tmp_path):
    at = run(page, monkeypatch, tmp_path)
    assert not at.exception, [e.value for e in at.exception]


def test_home_states_prototype_and_unconfigured_model(monkeypatch, tmp_path):
    txt = text_of(run("Home", monkeypatch, tmp_path))
    assert "educational and research prototype" in txt
    assert "Model not configured" in txt


def test_model_page_says_not_yet_evaluated_and_shows_no_numbers(monkeypatch, tmp_path):
    at = run("Model & Evaluation", monkeypatch, tmp_path)
    assert "Not yet evaluated" in text_of(at)
    assert len(at.metric) == 0 and len(at.dataframe) == 0 or all(
        "Accuracy" not in str(d.value) for d in at.dataframe)


def test_results_page_without_analysis_prompts_user(monkeypatch, tmp_path):
    assert "No analysis yet" in text_of(run("Results", monkeypatch, tmp_path))


def test_about_page_has_placeholders_not_invented_contacts(monkeypatch, tmp_path):
    at = run("About & Safety", monkeypatch, tmp_path)
    dfs = [d.value.to_string() for d in at.dataframe]
    assert any("[Your name here]" in d for d in dfs)


def test_results_page_with_model_shows_report_downloads(monkeypatch, tmp_path, tiny_checkpoint, fundus):
    m = model_loader.load_model(tiny_checkpoint)
    res = inference.run_screening(fundus, m, anon_id=privacy.anonymous_id(b"x"),
                                  ucfg=uncertainty.UncertaintyConfig(0, 0, 1))
    at = run("Results", monkeypatch, tmp_path, model_path=tiny_checkpoint,
             state={"result": res, "result_filename": "eye.png"})
    assert not at.exception, [e.value for e in at.exception]
    txt = text_of(at)
    assert res.decision.predicted_label in txt and "not a calibrated clinical probability" in txt
    assert len(at.get("download_button")) == 3


def test_results_page_without_model_shows_no_category(monkeypatch, tmp_path, fundus):
    m = model_loader.load_model(tmp_path / "missing.pt")
    res = inference.run_screening(fundus, m, anon_id="RS-NOMODEL01")
    at = run("Results", monkeypatch, tmp_path, state={"result": res, "result_filename": "x.png"})
    assert not at.exception
    txt = text_of(at)
    assert "Model not configured" in txt
    for name in config.CLASS_NAMES:
        assert f"Model output: {name}" not in txt


def test_model_page_with_smoke_checkpoint_warns(monkeypatch, tmp_path, tiny_checkpoint):
    import torch
    ck = torch.load(tiny_checkpoint, weights_only=True)
    ck["smoke_test"] = True
    p = tmp_path / "smoke.pt"
    torch.save(ck, p)
    at = run("Model & Evaluation", monkeypatch, tmp_path, model_path=p)
    assert not at.exception
    assert "Demo mode" in text_of(at)
