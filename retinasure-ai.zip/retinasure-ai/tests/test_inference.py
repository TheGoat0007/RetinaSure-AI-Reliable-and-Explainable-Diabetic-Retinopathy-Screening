import numpy as np
import pytest

from src import config, inference, model_loader, uncertainty
from src.inference import InferenceError

torch = pytest.importorskip("torch")


# --------------------------- model loading ---------------------------------- #
def test_missing_weights_is_unconfigured(tmp_path):
    m = model_loader.load_model(tmp_path / "nope.pt")
    assert m.status == "unconfigured" and not m.usable and "train" in m.message.lower()


def test_corrupt_checkpoint_gives_error_not_exception(tmp_path):
    p = tmp_path / "bad.pt"
    p.write_bytes(b"this is not a checkpoint")
    m = model_loader.load_model(p)
    assert m.status == "error" and not m.usable


def test_checkpoint_missing_fields_is_error(tmp_path):
    p = tmp_path / "partial.pt"
    torch.save({"state_dict": {}}, p)
    assert model_loader.load_model(p).status == "error"


def test_wrong_weights_for_architecture_is_error(tmp_path):
    p = tmp_path / "mismatch.pt"
    torch.save({"state_dict": {"fc.weight": torch.zeros(1)}, "arch": "resnet18", "num_classes": 5,
                "img_size": 64, "class_names": config.CLASS_NAMES}, p)
    assert model_loader.load_model(p).status == "error"


def test_unsafe_pickle_is_not_executed(tmp_path):
    """weights_only loading must refuse a pickle that would run code."""
    import os
    import pickle

    marker = tmp_path / "pwned.txt"

    class Evil:
        def __reduce__(self):
            return (os.system, (f"echo hacked > {marker}",))

    p = tmp_path / "evil.pt"
    with open(p, "wb") as fh:
        pickle.dump({"state_dict": Evil()}, fh)
    m = model_loader.load_model(p)
    assert m.status == "error" and not marker.exists()


def test_smoke_test_checkpoint_is_demo_only(tmp_path, tiny_checkpoint):
    ckpt = torch.load(tiny_checkpoint, weights_only=True)
    ckpt["smoke_test"] = True
    p = tmp_path / "smoke.pt"
    torch.save(ckpt, p)
    m = model_loader.load_model(p)
    assert m.status == "demo_only" and not m.usable
    with pytest.raises(InferenceError):
        inference.predict(m, np.zeros((64, 64, 3), np.uint8))


def test_valid_checkpoint_loads(tiny_checkpoint):
    m = model_loader.load_model(tiny_checkpoint)
    assert m.usable and m.arch == "resnet18" and m.img_size == 64 and len(m.meta["sha256"]) == 64


# --------------------------- inference -------------------------------------- #
def test_predict_without_model_raises(tmp_path):
    with pytest.raises(InferenceError):
        inference.predict(model_loader.load_model(tmp_path / "nope.pt"), np.zeros((64, 64, 3), np.uint8))


def test_predict_returns_valid_distribution(tiny_checkpoint, fundus):
    m = model_loader.load_model(tiny_checkpoint)
    from src.preprocessing import preprocess_image
    p = inference.predict(m, preprocess_image(fundus, 64))
    assert len(p.probs) == 5 and abs(sum(p.probs) - 1) < 1e-5
    assert p.class_index == int(np.argmax(p.probs)) and 0 <= p.entropy <= 1


def test_no_model_never_fabricates_a_prediction(tmp_path, fundus):
    res = inference.run_screening(fundus, model_loader.load_model(tmp_path / "nope.pt"), anon_id="RS-X")
    assert res.prediction is None and res.explain is None
    assert res.decision.status == uncertainty.NO_MODEL and not res.decision.has_prediction
    assert res.decision.predicted_label is None and res.decision.confidence is None
    assert "not configured" in res.decision.title.lower()


def test_bad_image_blocks_model(tiny_checkpoint):
    m = model_loader.load_model(tiny_checkpoint)
    res = inference.run_screening(np.zeros((640, 640, 3), np.uint8), m, anon_id="RS-X")
    assert res.decision.status == uncertainty.UNGRADABLE
    assert res.prediction is None and res.explain is None


def test_run_screening_with_model_end_to_end(tiny_checkpoint, fundus):
    """Plumbing test with RANDOM weights: outputs are meaningless but the flow must work."""
    m = model_loader.load_model(tiny_checkpoint)
    loose = uncertainty.UncertaintyConfig(0.0, 0.0, 1.0)
    res = inference.run_screening(fundus, m, anon_id="RS-X", ucfg=loose)
    assert res.prediction is not None and res.decision.status == uncertainty.REPORTED
    assert res.decision.predicted_label == config.CLASS_NAMES[res.prediction.class_index]
    assert res.explain is not None
    assert res.original_preview is not None and res.processed.shape == (64, 64, 3)


def test_inference_failure_is_reported_not_raised(tiny_checkpoint, fundus, monkeypatch):
    m = model_loader.load_model(tiny_checkpoint)

    def boom(*a, **k):
        raise RuntimeError("kaboom")

    monkeypatch.setattr(m, "model", type("M", (), {"__call__": boom})())
    res = inference.run_screening(fundus, m, anon_id="RS-X")
    assert res.prediction is None and res.inference_error
    assert res.decision.status == uncertainty.NO_MODEL


def test_batch_style_run_without_explainability(tiny_checkpoint, fundus):
    m = model_loader.load_model(tiny_checkpoint)
    res = inference.run_screening(fundus, m, anon_id="RS-X", explain=False,
                                  ucfg=uncertainty.UncertaintyConfig(0, 0, 1))
    assert res.explain is None and res.prediction is not None


# --------------------------- explainability --------------------------------- #
def test_gradcam_matches_model_and_input(tiny_checkpoint, fundus):
    from src.explainability import compute_gradcam
    from src.preprocessing import preprocess_image
    m = model_loader.load_model(tiny_checkpoint)
    proc = preprocess_image(fundus, 64)
    ex = compute_gradcam(m, proc, target_class=2)
    assert ex.available and ex.target_class == 2
    assert ex.heatmap.shape == (64, 64) and 0 <= ex.heatmap.min() and ex.heatmap.max() <= 1 + 1e-6
    assert ex.overlay.shape == (64, 64, 3) and ex.overlay.dtype == np.uint8
    other = compute_gradcam(m, preprocess_image(np.flip(fundus, 0).copy(), 64), target_class=2)
    assert not np.allclose(ex.heatmap, other.heatmap)  # depends on the input, not decorative


def test_gradcam_leaves_model_clean(tiny_checkpoint, fundus):
    from src.explainability import compute_gradcam
    from src.preprocessing import preprocess_image
    m = model_loader.load_model(tiny_checkpoint)
    compute_gradcam(m, preprocess_image(fundus, 64))
    assert all(p.grad is None for p in m.model.parameters())
    assert len(m.model.layer4[-1]._forward_hooks) == 0


def test_gradcam_without_model_is_graceful(tmp_path):
    from src.explainability import compute_gradcam
    ex = compute_gradcam(model_loader.load_model(tmp_path / "x.pt"), np.zeros((64, 64, 3), np.uint8))
    assert not ex.available and ex.heatmap is None and ex.overlay is None


def test_gradcam_internal_error_is_graceful(tiny_checkpoint, monkeypatch):
    from src import explainability
    m = model_loader.load_model(tiny_checkpoint)
    monkeypatch.setattr(explainability, "gradcam_target_layer", lambda *a: (_ for _ in ()).throw(ValueError("x")))
    ex = explainability.compute_gradcam(m, np.zeros((64, 64, 3), np.uint8))
    assert not ex.available and "could not be computed" in ex.message


def test_legend_bar_shape():
    from src.explainability import legend_bar
    assert legend_bar(100, 10).shape == (10, 100, 3)


# --------------------- default architecture (EfficientNet-B0) ---------------- #
def test_efficientnet_default_arch_end_to_end(tmp_path, fundus):
    """The shipped default architecture must load, predict and produce Grad-CAM.
    Random weights: this checks plumbing only."""
    from src.explainability import compute_gradcam
    from src.preprocessing import preprocess_image

    torch.manual_seed(0)
    net = model_loader.build_model("efficientnet_b0", 5, pretrained=False)
    p = tmp_path / "eff.pt"
    torch.save({"state_dict": net.state_dict(), "arch": "efficientnet_b0", "num_classes": 5,
                "img_size": 96, "class_names": config.CLASS_NAMES, "version": "t"}, p)
    m = model_loader.load_model(p)
    assert m.usable and m.arch == "efficientnet_b0"
    proc = preprocess_image(fundus, 96)
    pred = inference.predict(m, proc)
    assert abs(sum(pred.probs) - 1) < 1e-5
    ex = compute_gradcam(m, proc)
    assert ex.available, ex.message
    assert ex.heatmap.shape == (96, 96) and len(m.model.features[-1]._forward_hooks) == 0
