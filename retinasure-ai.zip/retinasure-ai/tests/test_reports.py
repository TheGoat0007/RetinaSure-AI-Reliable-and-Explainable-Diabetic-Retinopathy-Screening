import csv
import io

import pytest

from src import config, inference, model_loader, report_generator as rg, uncertainty

torch = pytest.importorskip("torch")
LOOSE = uncertainty.UncertaintyConfig(0.0, 0.0, 1.0)


@pytest.fixture()
def no_model_result(tmp_path, fundus):
    return inference.run_screening(fundus, model_loader.load_model(tmp_path / "x.pt"), anon_id="RS-TEST000001")


@pytest.fixture()
def model_result(tiny_checkpoint, fundus):
    m = model_loader.load_model(tiny_checkpoint)
    return inference.run_screening(fundus, m, anon_id="RS-TEST000002", ucfg=LOOSE)


def test_html_without_model_contains_no_finding(no_model_result):
    html = rg.generate_html(no_model_result)
    assert "No severity category is provided" in html
    for name in config.CLASS_NAMES:
        assert f"Model output:</strong> {name}" not in html
    assert "Softmax confidence" not in html and "Grad-CAM overlay" not in html
    assert config.SHORT_DISCLAIMER in html and "not a medical diagnosis" in html.lower()
    assert "does NOT rule out diabetic retinopathy" in html


def test_html_with_model_shows_output_and_images(model_result):
    html = rg.generate_html(model_result)
    assert f"Model output:</strong> {model_result.decision.predicted_label}" in html
    assert "not a calibrated clinical probability" in html
    assert html.count("data:image/png;base64,") == 2
    assert "not a lesion map" in html.lower()


def test_html_can_omit_images(model_result):
    assert "data:image/png" not in rg.generate_html(model_result, include_images=False)


def test_filename_is_excluded_by_default_and_escaped_when_included(no_model_result):
    assert "patient_jane" not in rg.generate_html(no_model_result)
    evil = '<script>alert(1)</script>patient_jane.png'
    html = rg.generate_html(no_model_result, filename=evil)
    assert "<script>alert(1)</script>" not in html and "&lt;script&gt;" in html


def test_report_has_no_personal_data_fields(no_model_result):
    html = rg.generate_html(no_model_result).lower()
    assert "date of birth" not in html.replace("no patient name, date of birth or patient id", "")
    assert "RS-TEST000001" in rg.generate_html(no_model_result)


def test_pdf_is_valid_and_contains_disclaimer(model_result, no_model_result):
    for r in (model_result, no_model_result):
        pdf = rg.generate_pdf(r)
        assert pdf.startswith(b"%PDF") and len(pdf) > 2000
    assert rg.generate_pdf(model_result, include_images=False)[:4] == b"%PDF"


def test_pdf_handles_special_characters_in_filename(no_model_result):
    assert rg.generate_pdf(no_model_result, filename="résumé <b>&.png").startswith(b"%PDF")


def test_csv_without_model_has_empty_prediction(no_model_result):
    rows = list(csv.DictReader(io.StringIO(rg.generate_csv([no_model_result]))))
    assert rows[0]["predicted_class"] == "" and rows[0]["confidence"] == ""
    assert rows[0]["decision_status"] == uncertainty.NO_MODEL and rows[0]["reference"] == "RS-TEST000001"


def test_csv_with_model_and_multiple_rows(model_result, no_model_result):
    rows = list(csv.DictReader(io.StringIO(rg.generate_csv([model_result, no_model_result]))))
    assert len(rows) == 2 and rows[0]["predicted_class"] in config.CLASS_NAMES
    assert set(rows[0]) == set(rg.CSV_FIELDS)


def test_ungradable_report_has_no_category(tiny_checkpoint):
    import numpy as np
    m = model_loader.load_model(tiny_checkpoint)
    r = inference.run_screening(np.zeros((640, 640, 3), np.uint8), m, anon_id="RS-BAD", ucfg=LOOSE)
    html = rg.generate_html(r)
    assert "Image not suitable" in html and "No severity category is provided" in html
