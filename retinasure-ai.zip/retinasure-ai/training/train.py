"""Train a diabetic-retinopathy grading model.

    python training/train.py --csv data/aptos/train.csv --image-dir data/aptos/train_images `
        --dataset-name "APTOS 2019 (Kaggle)" --epochs 15 --pretrained

What it does
  1. Loads labels and makes a stratified, PATIENT-LEVEL train/val/test split (saved to --splits-dir).
     The test split is never used here.
  2. Handles class imbalance with class-weighted cross-entropy (disable with --no-class-weights).
  3. Trains with fixed seeds; tracks train/val loss and validation quadratic-weighted kappa (QWK).
  4. Saves the best-validation-QWK checkpoint plus <name>.history.json and <name>.loss.png.

--smoke-test marks the checkpoint as a pipeline test: the app refuses to use it for predictions.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np  # noqa: E402

from src import config  # noqa: E402
from src.model_loader import build_model, save_checkpoint  # noqa: E402
from training import dataset as ds  # noqa: E402


def parse_args(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--csv", type=Path, required=True)
    p.add_argument("--image-dir", type=Path, required=True)
    p.add_argument("--id-col", default="id_code")
    p.add_argument("--label-col", default="diagnosis")
    p.add_argument("--patient-col", default=None, help="patient-ID column, so a patient stays in ONE split")
    p.add_argument("--dataset-name", required=True, help="recorded in the checkpoint, e.g. 'APTOS 2019 (Kaggle)'")
    p.add_argument("--arch", default=config.DEFAULT_ARCH, choices=config.SUPPORTED_ARCHS)
    p.add_argument("--img-size", type=int, default=config.DEFAULT_IMG_SIZE)
    p.add_argument("--preprocess", default="crop_resize", choices=("crop_resize", "ben_graham"))
    p.add_argument("--epochs", type=int, default=15)
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--weight-decay", type=float, default=1e-4)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--workers", type=int, default=0, help="data-loader workers (0 = fully reproducible)")
    p.add_argument("--pretrained", action="store_true", help="start from ImageNet weights (downloads them once)")
    p.add_argument("--no-class-weights", action="store_true")
    p.add_argument("--smoke-test", action="store_true", help="mark checkpoint as a pipeline test (not usable by the app)")
    p.add_argument("--val-frac", type=float, default=0.15)
    p.add_argument("--test-frac", type=float, default=0.15)
    p.add_argument("--output", type=Path, default=config.DEFAULT_MODEL_PATH)
    p.add_argument("--splits-dir", type=Path, default=Path("data/splits"))
    p.add_argument("--version", default="0.1.0")
    p.add_argument("--notes", default="")
    p.add_argument("--device", default="auto")
    return p.parse_args(argv)


def run_epoch(model, loader, criterion, device, optimizer=None):
    import torch
    from sklearn.metrics import cohen_kappa_score

    train = optimizer is not None
    model.train(train)
    total, n, preds, labels = 0.0, 0, [], []
    with torch.enable_grad() if train else torch.no_grad():
        for x, y in loader:
            x, y = x.to(device), y.to(device)
            out = model(x)
            loss = criterion(out, y)
            if train:
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                optimizer.step()
            total += float(loss.item()) * len(y)
            n += len(y)
            preds.append(out.argmax(1).cpu().numpy())
            labels.append(y.cpu().numpy())
    p, l = np.concatenate(preds), np.concatenate(labels)
    qwk = cohen_kappa_score(l, p, weights="quadratic", labels=list(range(config.NUM_CLASSES)))
    return total / max(n, 1), float(np.mean(p == l)), float(qwk) if np.isfinite(qwk) else 0.0


def save_loss_plot(history: list[dict], path: Path) -> None:
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from matplotlib.figure import Figure

    fig = Figure(figsize=(6, 3.6), dpi=120)
    FigureCanvasAgg(fig)
    ax = fig.subplots()
    ep = [h["epoch"] for h in history]
    ax.plot(ep, [h["train_loss"] for h in history], marker="o", label="train loss", color="#0B1F3A")
    ax.plot(ep, [h["val_loss"] for h in history], marker="o", label="validation loss", color="#0B7A85")
    ax.set_xlabel("epoch")
    ax.set_ylabel("loss")
    ax.legend()
    fig.tight_layout()
    fig.savefig(path)


def main(argv=None) -> dict:
    import torch
    from torch.utils.data import DataLoader

    a = parse_args(argv)
    ds.seed_everything(a.seed)
    device = torch.device("cuda" if a.device == "auto" and torch.cuda.is_available() else ("cpu" if a.device == "auto" else a.device))

    table = ds.load_table(a.csv, a.image_dir, a.id_col, a.label_col, a.patient_col)
    splits = ds.split_table(table, a.val_frac, a.test_frac, a.seed)
    ds.save_splits(splits, a.splits_dir)
    for name, df in splits.items():
        print(f"{name:5s} n={len(df):5d}  classes={ds.class_distribution(df['label'])}")
    if not a.patient_col:
        print("[note] no --patient-col given: each image is treated as its own patient. If one patient has several "
              "images, pass --patient-col to prevent leakage.")

    train_ds = ds.FundusDataset(splits["train"], a.img_size, a.preprocess, augment=True, seed=a.seed)
    val_ds = ds.FundusDataset(splits["val"], a.img_size, a.preprocess)
    gen = torch.Generator().manual_seed(a.seed)
    train_dl = DataLoader(train_ds, batch_size=a.batch_size, shuffle=True, num_workers=a.workers, generator=gen)
    val_dl = DataLoader(val_ds, batch_size=a.batch_size, shuffle=False, num_workers=a.workers)

    model = build_model(a.arch, pretrained=a.pretrained and not a.smoke_test).to(device)
    weights = None if a.no_class_weights else ds.class_weights(splits["train"]["label"].to_numpy())
    criterion = torch.nn.CrossEntropyLoss(weight=None if weights is None else torch.tensor(weights, device=device))
    optimizer = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=a.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(a.epochs, 1))

    history, best_qwk, best_epoch, best_state = [], -2.0, 0, None
    t0 = time.time()
    for epoch in range(1, a.epochs + 1):
        tr_loss, tr_acc, _ = run_epoch(model, train_dl, criterion, device, optimizer)
        va_loss, va_acc, va_qwk = run_epoch(model, val_dl, criterion, device)
        scheduler.step()
        history.append({"epoch": epoch, "train_loss": tr_loss, "val_loss": va_loss, "train_acc": tr_acc,
                        "val_acc": va_acc, "val_qwk": va_qwk})
        print(f"epoch {epoch:02d}/{a.epochs}  train_loss={tr_loss:.4f}  val_loss={va_loss:.4f}  val_acc={va_acc:.3f}  val_qwk={va_qwk:.3f}")
        if va_qwk > best_qwk:
            best_qwk, best_epoch = va_qwk, epoch
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    if best_state is not None:
        model.load_state_dict(best_state)

    out = a.output
    save_checkpoint(
        out, model, a.arch, a.img_size, a.preprocess,
        dataset_name=a.dataset_name, version=a.version, notes=a.notes, seed=a.seed, epochs=a.epochs,
        best_epoch=best_epoch, val_qwk=float(best_qwk), lr=a.lr, batch_size=a.batch_size,
        patient_level_split=bool(a.patient_col), pretrained=bool(a.pretrained and not a.smoke_test),
        smoke_test=bool(a.smoke_test), n_train=len(splits["train"]), n_val=len(splits["val"]), n_test=len(splits["test"]),
        class_weights=None if weights is None else [float(x) for x in weights])
    out.with_suffix(".history.json").write_text(json.dumps(history, indent=2))
    save_loss_plot(history, out.with_suffix(".loss.png"))
    print(f"Saved {out} (best epoch {best_epoch}, val QWK {best_qwk:.3f}) in {time.time() - t0:.0f}s")
    if a.smoke_test:
        print("SMOKE TEST: this checkpoint is marked demo-only and will NOT be used for predictions by the app.")
    return {"history": history, "best_epoch": best_epoch}


if __name__ == "__main__":
    main()
