"""Dataset loading, patient-level splitting, class weights and a PyTorch-style Dataset.

Expected input is a CSV with one row per image. Defaults match APTOS 2019 (`id_code`, `diagnosis`;
images in a folder as `<id_code>.png`). If the dataset has patient identifiers (both eyes of a patient,
or repeat visits) pass --patient-col so a patient never appears in more than one split (no leakage).
Nothing here downloads data: see docs/DATASET_GUIDE.md for legitimate sources and licences.
"""
from __future__ import annotations

import random
import sys
import warnings
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src import config  # noqa: E402
from src.preprocessing import normalize, preprocess_image  # noqa: E402

IMG_EXTS = (".png", ".jpg", ".jpeg", ".tif", ".tiff")


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    import torch

    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.use_deterministic_algorithms(True, warn_only=True)


def _find(image_dir: Path, image_id: str) -> Optional[Path]:
    p = image_dir / str(image_id)
    if p.suffix.lower() in IMG_EXTS and p.is_file():
        return p
    for ext in IMG_EXTS:
        cand = image_dir / f"{image_id}{ext}"
        if cand.is_file():
            return cand
    return None


def load_table(csv_path: Path | str, image_dir: Path | str, id_col: str = "id_code", label_col: str = "diagnosis",
               patient_col: Optional[str] = None) -> pd.DataFrame:
    """Return a DataFrame with columns image_id, label, patient_id, path. Raises ValueError on bad labels."""
    raw = pd.read_csv(csv_path)
    needed = [id_col, label_col] + ([patient_col] if patient_col else [])
    for col in needed:
        if col not in raw.columns:
            raise ValueError(f"Column '{col}' not found in {csv_path}. Columns present: {list(raw.columns)}")
    label = pd.to_numeric(raw[label_col], errors="coerce")
    bad = label.isna() | ~label.isin(range(config.NUM_CLASSES))
    if bad.any():
        raise ValueError(f"{int(bad.sum())} rows have labels outside 0..{config.NUM_CLASSES - 1}.")
    t = pd.DataFrame({"image_id": raw[id_col].astype(str), "label": label.astype(int)})
    t["patient_id"] = raw[patient_col].astype(str) if patient_col else t["image_id"]
    paths = [_find(Path(image_dir), i) for i in t["image_id"]]
    t["path"] = [str(p) if p else "" for p in paths]
    missing = int((t["path"] == "").sum())
    if missing:
        print(f"[warning] {missing} listed image(s) were not found in {image_dir} and were dropped.")
    t = t[t["path"] != ""].reset_index(drop=True)
    if t.empty:
        raise ValueError(f"No images found in {image_dir}. Check --image-dir and --id-col.")
    return t


def split_table(table: pd.DataFrame, val_frac: float = 0.15, test_frac: float = 0.15, seed: int = 42) -> dict[str, pd.DataFrame]:
    """Stratified, patient-grouped train/val/test split. Reproducible for a given seed."""
    from sklearn.model_selection import StratifiedGroupKFold

    def carve(frame: pd.DataFrame, frac: float, s: int):
        folds = max(2, round(1 / frac))
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            rest, held = next(StratifiedGroupKFold(n_splits=folds, shuffle=True, random_state=s)
                              .split(frame, frame["label"], groups=frame["patient_id"]))
        return frame.iloc[rest].reset_index(drop=True), frame.iloc[held].reset_index(drop=True)

    trainval, test = carve(table, test_frac, seed)
    train, val = carve(trainval, val_frac / (1.0 - test_frac), seed + 1)
    out = {"train": train, "val": val, "test": test}
    for a, b in (("train", "val"), ("train", "test"), ("val", "test")):
        shared = set(out[a]["patient_id"]) & set(out[b]["patient_id"])
        assert not shared, f"Patient leakage between {a} and {b}: {len(shared)} shared patient(s)"
    return out


def save_splits(splits: dict[str, pd.DataFrame], out_dir: Path | str) -> None:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    for name, df in splits.items():
        df.to_csv(out_dir / f"{name}.csv", index=False)


def class_distribution(labels) -> dict[str, int]:
    counts = np.bincount(np.asarray(labels, dtype=int), minlength=config.NUM_CLASSES)
    return {config.CLASS_NAMES[i]: int(counts[i]) for i in range(config.NUM_CLASSES)}


def class_weights(labels, num_classes: int = config.NUM_CLASSES) -> np.ndarray:
    """Inverse-frequency weights over the classes that occur (absent classes get weight 0), mean 1 over present."""
    counts = np.bincount(np.asarray(labels, dtype=int), minlength=num_classes).astype(np.float64)
    present = counts > 0
    w = np.zeros(num_classes)
    w[present] = counts.sum() / (present.sum() * counts[present])
    return (w / w[present].mean()).astype(np.float32) if present.any() else w.astype(np.float32)


class FundusDataset:
    """torch-compatible dataset: implements __len__ and __getitem__ (returns normalised tensor, label)."""

    def __init__(self, table: pd.DataFrame, img_size: int, preprocess: str = "crop_resize", augment: bool = False, seed: int = 0):
        self.table = table.reset_index(drop=True)
        self.img_size, self.preprocess, self.augment = img_size, preprocess, augment
        self.rng = np.random.default_rng(seed)

    def __len__(self) -> int:
        return len(self.table)

    def _augment(self, img: np.ndarray) -> np.ndarray:
        import cv2

        r = self.rng
        if r.random() < 0.5:
            img = img[:, ::-1]
        if r.random() < 0.5:
            img = img[::-1, :]
        h, w = img.shape[:2]
        m = cv2.getRotationMatrix2D((w / 2, h / 2), float(r.uniform(-180, 180)), 1.0)
        img = cv2.warpAffine(np.ascontiguousarray(img), m, (w, h), flags=cv2.INTER_LINEAR, borderValue=0)
        return np.clip(img.astype(np.float32) * float(r.uniform(0.85, 1.15)) + float(r.uniform(-12, 12)), 0, 255).astype(np.uint8)

    def __getitem__(self, i: int):
        import torch
        from PIL import Image

        row = self.table.iloc[i]
        with Image.open(row["path"]) as im:
            rgb = np.asarray(im.convert("RGB"), dtype=np.uint8)
        img = preprocess_image(rgb, self.img_size, self.preprocess)
        if self.augment:
            img = self._augment(img)
        return torch.from_numpy(normalize(img)), int(row["label"])
