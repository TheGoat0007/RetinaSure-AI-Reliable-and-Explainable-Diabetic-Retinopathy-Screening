"""Evaluate a checkpoint on a labelled split and write evaluation_metrics*.json (+ confusion-matrix PNG).

    python training/evaluate.py --checkpoint models/retinasure_dr.pt --csv data/splits/test.csv
    python training/evaluate.py --checkpoint models/retinasure_dr.pt --csv data/splits/val.csv --role val

--role test  (default) -> evaluation_metrics.json       (the numbers the app shows; use the TEST split once)
--role val              -> evaluation_metrics_val.json   (use this to choose abstention thresholds)
--role external         -> evaluation_metrics_external.json (a different dataset: best check of generalisation)

Nothing here produces numbers unless real labelled images are run through the real model.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from src import config  # noqa: E402

K = config.NUM_CLASSES
THRESHOLDS = (0.0, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9)


def _f(x):
    """JSON-safe float (None for nan/inf)."""
    return None if x is None or not math.isfinite(float(x)) else float(x)


def wilson_interval(k: int, n: int, z: float = 1.96):
    """95% Wilson score interval for a proportion k/n; None when n == 0."""
    if n <= 0:
        return None
    p = k / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return (max(0.0, centre - half), min(1.0, centre + half))


def expected_calibration_error(conf, correct, bins: int = 15) -> float:
    conf, correct = np.asarray(conf, float), np.asarray(correct, float)
    edges = np.linspace(0, 1, bins + 1)
    ece = 0.0
    for lo, hi in zip(edges[:-1], edges[1:]):
        sel = (conf > lo) & (conf <= hi) if lo > 0 else (conf >= lo) & (conf <= hi)
        if sel.any():
            ece += sel.mean() * abs(correct[sel].mean() - conf[sel].mean())
    return float(ece)


def binary_endpoint(y_true: np.ndarray, y_pred: np.ndarray, threshold: int) -> dict:
    t, p = y_true >= threshold, y_pred >= threshold
    tp, fn, tn, fp = int((t & p).sum()), int((t & ~p).sum()), int((~t & ~p).sum()), int((~t & p).sum())
    sens = tp / (tp + fn) if tp + fn else None
    spec = tn / (tn + fp) if tn + fp else None
    return {"definition": f"positive means grade >= {threshold}", "tp": tp, "fn": fn, "tn": tn, "fp": fp,
            "sensitivity": sens, "sensitivity_ci95": wilson_interval(tp, tp + fn),
            "specificity": spec, "specificity_ci95": wilson_interval(tn, tn + fp)}


def compute_metrics(y_true, probs) -> dict:
    from sklearn.metrics import (accuracy_score, cohen_kappa_score, confusion_matrix,
                                 precision_recall_fscore_support, roc_auc_score)

    y_true = np.asarray(y_true, dtype=int)
    probs = np.asarray(probs, dtype=float)
    if probs.ndim != 2 or probs.shape[1] != K or len(probs) != len(y_true):
        raise ValueError(f"probs must have shape (n_samples, {K}) matching y_true.")
    y_pred = probs.argmax(1)
    labels = list(range(K))
    p, r, f1, sup = precision_recall_fscore_support(y_true, y_pred, labels=labels, zero_division=0)
    present = [c for c in labels if (y_true == c).any()]
    macro = precision_recall_fscore_support(y_true, y_pred, labels=present, average="macro", zero_division=0)[:3]
    auc = {}
    for c in labels:
        pos = y_true == c
        auc[config.CLASS_NAMES[c]] = _f(roc_auc_score(pos, probs[:, c])) if pos.any() and (~pos).any() else None
    defined = [v for v in auc.values() if v is not None]
    qwk = cohen_kappa_score(y_true, y_pred, weights="quadratic", labels=labels) if len(np.unique(np.r_[y_true, y_pred])) > 1 else None
    conf = probs.max(1)
    correct = y_pred == y_true
    rows = []
    for th in THRESHOLDS:
        keep = conf >= th
        rows.append({"min_confidence": th, "coverage": float(keep.mean()), "n_answered": int(keep.sum()),
                     "accuracy_on_answered": float(correct[keep].mean()) if keep.any() else None})
    return {
        "n_samples": int(len(y_true)),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "macro_precision": float(macro[0]), "macro_recall": float(macro[1]), "macro_f1": float(macro[2]),
        "macro_computed_over_classes": [config.CLASS_NAMES[c] for c in present],
        "quadratic_weighted_kappa": _f(qwk),
        "per_class": {config.CLASS_NAMES[c]: {"precision": float(p[c]), "recall": float(r[c]), "f1": float(f1[c]),
                                              "support": int(sup[c])} for c in labels},
        "class_distribution": {config.CLASS_NAMES[c]: int((y_true == c).sum()) for c in labels},
        "confusion_matrix": confusion_matrix(y_true, y_pred, labels=labels).tolist(),
        "roc_auc_ovr": auc, "roc_auc_ovr_macro": float(np.mean(defined)) if defined else None,
        "any_dr": binary_endpoint(y_true, y_pred, 1),
        "referable_dr": binary_endpoint(y_true, y_pred, config.REFERABLE_THRESHOLD),
        "expected_calibration_error": expected_calibration_error(conf, correct),
        "risk_coverage": {"note": "Coverage = share of images that would still receive a category if scores below "
                                  "the threshold were withheld. Choose thresholds on the VALIDATION split.",
                          "by_min_confidence": rows},
    }


def check_no_leakage(csv_path: Path | str) -> None:
    """If a sibling train.csv exists, abort when it shares patients (or images) with the evaluated CSV."""
    csv_path = Path(csv_path)
    train_csv = csv_path.parent / "train.csv"
    if csv_path.name == "train.csv" or not train_csv.is_file():
        return
    ev, tr = pd.read_csv(csv_path), pd.read_csv(train_csv)
    col = "patient_id" if "patient_id" in ev.columns and "patient_id" in tr.columns else "image_id"
    shared = set(ev[col].astype(str)) & set(tr[col].astype(str))
    if shared:
        raise SystemExit(f"LEAKAGE: {len(shared)} {col}(s) in {csv_path.name} also appear in train.csv "
                         f"(e.g. {sorted(shared)[:3]}). Evaluation aborted: results would be meaningless.")


def save_confusion_png(cm: list, path: Path) -> None:
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from matplotlib.figure import Figure

    fig = Figure(figsize=(5.6, 4.8), dpi=120)
    FigureCanvasAgg(fig)
    ax = fig.subplots()
    arr = np.array(cm)
    im = ax.imshow(arr, cmap="Blues")
    ax.set_xticks(range(K), config.CLASS_NAMES, rotation=35, ha="right", fontsize=8)
    ax.set_yticks(range(K), config.CLASS_NAMES, fontsize=8)
    ax.set_xlabel("predicted")
    ax.set_ylabel("true")
    for i in range(K):
        for j in range(K):
            ax.text(j, i, int(arr[i, j]), ha="center", va="center", fontsize=9,
                    color="white" if arr[i, j] > arr.max() / 2 else "#0B1F3A")
    fig.colorbar(im, ax=ax, fraction=0.046)
    fig.tight_layout()
    fig.savefig(path)


def predict_table(m, table: pd.DataFrame):
    from PIL import Image

    from src.inference import predict_unchecked
    from src.preprocessing import preprocess_image

    probs, labels = [], []
    for _, row in table.iterrows():
        with Image.open(row["path"]) as im:
            rgb = np.asarray(im.convert("RGB"), dtype=np.uint8)
        probs.append(predict_unchecked(m, preprocess_image(rgb, m.img_size, m.preprocess)).probs)
        labels.append(int(row["label"]))
    return np.array(labels), np.array(probs)


def main(argv=None) -> dict:
    from src.model_loader import load_model

    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--checkpoint", type=Path, default=config.DEFAULT_MODEL_PATH)
    ap.add_argument("--csv", type=Path, required=True, help="CSV with 'path' and 'label' columns (as written by train.py)")
    ap.add_argument("--role", default="test", choices=("test", "val", "external"))
    ap.add_argument("--dataset-name", default=None, help="name of the evaluated dataset (for external data)")
    ap.add_argument("--image-dir", type=Path, default=None, help="only for a raw CSV without a 'path' column")
    ap.add_argument("--id-col", default="id_code")
    ap.add_argument("--label-col", default="diagnosis")
    a = ap.parse_args(argv)

    if a.role != "external":
        check_no_leakage(a.csv)
    m = load_model(a.checkpoint)
    if m.model is None:
        raise SystemExit(f"Cannot evaluate: {m.message}")
    table = pd.read_csv(a.csv)
    if "path" not in table.columns:
        if a.image_dir is None:
            raise SystemExit("The CSV has no 'path' column; pass --image-dir (and --id-col/--label-col).")
        from training.dataset import load_table
        table = load_table(a.csv, a.image_dir, a.id_col, a.label_col)
    y, probs = predict_table(m, table)
    res = compute_metrics(y, probs)
    res["provenance"] = {
        "role": a.role, "evaluated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "checkpoint_sha256": m.meta.get("sha256", ""), "model_version": m.meta.get("version", ""),
        "model_training_dataset": m.meta.get("dataset_name", ""), "evaluated_dataset": a.dataset_name or m.meta.get("dataset_name", ""),
        "csv_name": a.csv.name, "smoke_test": bool(m.meta.get("smoke_test", False)),
        "patient_level_split": bool(m.meta.get("patient_level_split", False)), "calibration_assessed_by": "ECE on this split only",
        "caveat": "Single-dataset result; does not establish clinical validity.",
    }
    stem = "evaluation_metrics" if a.role == "test" else f"evaluation_metrics_{a.role}"
    out = a.checkpoint.parent / f"{stem}.json"
    out.write_text(json.dumps(res, indent=2))
    save_confusion_png(res["confusion_matrix"], out.with_suffix(".confusion.png"))
    print(f"n={res['n_samples']}  accuracy={res['accuracy']:.3f}  QWK={res['quadratic_weighted_kappa']}  -> {out}")
    if res["provenance"]["smoke_test"]:
        print("WARNING: smoke-test checkpoint; these numbers only prove the pipeline runs.")
    return res


if __name__ == "__main__":
    main()
