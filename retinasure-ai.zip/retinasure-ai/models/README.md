# models/

Put your trained checkpoint here as `retinasure_dr.pt` (or set `RETINASURE_MODEL_PATH`).

- Create it with `python training/train.py ...` (see README.md). Training also writes `retinasure_dr.history.json` and `retinasure_dr.loss.png` here.
- `python training/evaluate.py ...` writes `evaluation_metrics.json` here. The app shows only what is in that file.
- `.pt` files are git-ignored by default. Read docs/DEPLOYMENT.md before committing weights: check that the licence of the data you trained on allows sharing a model.
- No weights are shipped with this project. Until you add a real checkpoint, the app runs in "Model not configured" mode and makes no predictions.
